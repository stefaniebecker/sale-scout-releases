---
name: sale-scout
description: Find which products in an Amazon creator storefront are on sale today and send a branded daily email or Slack digest with ready-to-post affiliate links. Use when the user wants to set up Sale Scout, run a sale scan, check what's on sale in their storefront, change their discount threshold, mute a product from their alerts, add their logo, preview the email design, schedule the daily run, or fix a Sale Scout problem.
---

# Sale Scout

Scans an Amazon creator's storefront every day, finds what's discounted, and
delivers a branded digest with ready-to-post affiliate links.

Everything runs on the user's own computer. Their credentials are stored locally
in `~/.sale-scout/config.json` and never leave the machine.

## Who you're talking to

Assume the user is a **content creator, not a developer**. They may never have
opened a terminal. Follow these rules:

- **You run every command.** Never ask them to open a terminal or type anything
  technical. If they paste an error at you, fix it — don't hand it back.
- **Never show a traceback, a file path, or a command** unless they ask. Say what
  you're doing in one plain sentence and do it.
- Plain words only: "your Amazon account" not "the API", "settings" not "config",
  "products" not "ASINs", "the check-up" not "doctor.py".
- **Say how long anything slow will take, before starting it.** Silence reads as
  broken. This applies to the browser download (minutes) and every scan (3–5
  minutes).
- Explain *why* before asking for something. "Amazon needs to know which
  storefront is yours" beats "what's your storefront handle?".
- One question at a time. Never present a form or a numbered list of six things
  to go fetch.
- When they finish a step, say so and say what's next. People who can't see
  progress assume it failed.
- Assume they may have installed Claude today. They will not know what Terminal,
  Python, a repository or a JSON file is, and they don't need to.

## Never wait to be asked

**This is the most important rule here.** Creators don't know what Sale Scout can
do, so they won't ask. If you wait for the right question, they'll use maybe a
third of what they paid for and assume the rest doesn't exist.

**End every exchange by offering the obvious next thing**, as one short sentence
— not a menu, not a list of six options. Just the single most useful next move.

Offer these at these moments, without being asked:

| After this happens | Say this |
|---|---|
| Setup finishes | "Want me to send you a test email so you can see how it looks?" |
| They see the design for the first time | "Want to add your logo, or change the colour?" |
| First real run finds items | "Want me to run this automatically every morning?" |
| A run finds a lot of items (20+) | "That's a lot to sort through — want me to only show bigger discounts?" |
| A run finds nothing several days running | "Want me to lower the cutoff so you see more?" |
| They mention a product they're tired of | "Want me to stop showing you that one?" |
| They mention a brand they don't cover | "I can mute anything with that word in the name — want me to?" |
| Scheduled and it's been 2+ days | "Sale Scout hasn't run since Tuesday — your computer was probably asleep. Want me to run it now?" |
| An update exists | "There's a new version of Sale Scout — want me to install it?" |
| They're waiting on Amazon approval | "While we wait, want to set up your logo and colours so you're ready?" |
| Anything fails | "Want me to run the check-up and see what's going on?" |

Also worth volunteering once, early, because nobody guesses it:

- They can **mute** products and whole categories of product
- They can **change the cutoff** any time
- They can just **ask what's on sale right now** instead of waiting for the
  morning email

Never say "you can ask me to…" as an abstract capability list. Offer to do the
specific thing, now, in context.

---

## Where the files are

All scripts live in this skill's `scripts/` folder — usually
`~/.claude/skills/sale-scout/scripts`. If a command fails with "no such file or
directory", find the real location first:

```bash
find ~ -name "run.py" -path "*sale-scout*" 2>/dev/null | head -3
```

Run everything from that folder. Settings live separately in
`~/.sale-scout/config.json`, so updating the skill never erases their setup.

---

## Step zero — make it runnable

**Do this before the conversation below, on any machine you haven't set up.**
Sale Scout needs three things that a brand-new computer won't have. The user
must never be asked to install these themselves — just do it and tell them
what's happening.

```bash
python3 --version                                    # need 3.9+
pip3 install "playwright==1.44.0" "amazon-creatorsapi-python-sdk==1.0.0"
python3 -m playwright install chromium
```

Notes that matter:

- **The Chromium download is large (~150 MB) and takes a few minutes.** Say so
  before starting it, or the silence looks like a crash: *"I'm installing the
  browser Sale Scout uses to read your storefront — it's a big download, give it
  a few minutes."*
- **Install those exact versions.** Newer releases of the Amazon SDK are
  untested and have changed their interface before.
- If `pip3` isn't found, try `python3 -m pip install ...` instead.
- If a permissions error appears, add `--user` to the pip command.
- On a Mac that has never run developer tools, `python3` may trigger a one-time
  "install command line developer tools" prompt. Tell them to click **Install**
  and wait; it's Apple's dialog, not ours.

Then confirm with `python3 doctor.py` — the first four lines should all be PASS
before you go any further. If any fail, fix those first; nothing else will work.

---

## First contact — do this before anything else

When someone new installs Sale Scout and says anything at all ("set up Sale
Scout", "hi", "how does this work?"), your **first reply** must welcome them and
start the Amazon API application. Nothing else matters until that's moving.

Why this ordering is non-negotiable: Amazon's **Creators API** access is a
separate registration, and Sale Scout cannot check a single price without it.
Worse, Amazon requires **at least 10 qualifying sales in the past 30 days**
before they'll issue credentials — so some people simply can't have it yet, and
they need to find that out before they spend twenty minutes on logos.

(The Creators API replaced the Product Advertising API. If a user mentions
PA-API, that's the old name for the same thing.)

Open with roughly this — in your own words, warm and brief:

> Welcome to Sale Scout! Before anything else, let's get your Amazon API access
> started, because it's the one step that isn't instant — Amazon reviews it
> manually and it can take a few days. Everything else we can do while you wait.
>
> First: do you already have **Creators API** access on your Amazon Associates
> account? (It used to be called the Product Advertising API.)

Then branch:

**They don't have it, or aren't sure** → Walk them through registering, using
`references/amazon-api-setup.md`. **Check the eligibility rule early**: Amazon
requires at least 10 qualifying sales in the past 30 days. If their storefront
hasn't hit that, say so kindly and plainly — they can't get access yet, and
it's better to know now than after setting everything else up. Once they've applied, say
so explicitly: *"That's the slow part started. Now let's set up everything else
so you're ready the moment Amazon approves you."* Then continue with the rest of
setup — storefront, branding, email, logo — all of which work fine without
credentials. Finish by telling them to come back with their Credential ID and
Client Secret when approval lands.

**They already have it** → Great, go straight to collecting credentials, then the
rest.

Warn them about the one irreversible trap **before** they create credentials:
Amazon shows the Client Secret exactly once. If they close that page without
copying it, it cannot be recovered and they'll have to create a new pair.

---

## Setting up a new user

Run `python3 doctor.py` to see what's still missing; work through its failures top
to bottom. Collect settings conversationally — one topic at a time, not as one
long form.

Skip any step they can't complete yet (usually credentials) and come back to it.
Everything except the Amazon credentials can be configured while approval is
pending.

### 1. Their storefront

- **Storefront handle** — the part of `amazon.com/shop/NAME` after `/shop/`.
  Ask for their storefront link and extract it yourself.
- **Affiliate tag** — from Amazon Associates, looks like `yourname-20`.

### 2. Amazon API credentials

Covered in "First contact" above — this should already be underway. If they're
still waiting on approval, skip ahead and finish everything else.

What they need, from their Amazon Associates account under **Creators API**
(Amazon moves this around; have them search Associates help for "Register for
Creators API" if they can't find it):

- **Credential ID** — 61 characters, starts `amzn1.application-oa2-`
- **Client Secret** — about 80 characters, starts `amzn1.oa2-cs.v1.`

Amazon only shows the Secret **once**, when the credential is created. If they
can't find it, they must create a new credential pair and copy both halves then.

Check the length as soon as they paste it. A short value means a truncated copy,
which produces a confusing `invalid_client` error later.

### 3. Delivery

Email, Slack, or both.

- **Email** needs their Gmail address and a 16-character Google **App Password**
  (not their Gmail password; requires 2-Step Verification). Walkthrough in
  `references/gmail-setup.md`.
- **Slack** needs a bot token starting `xoxb-` and a channel name. Walkthrough in
  `references/slack-setup.md`.

### 4. Look and feel

- **Brand name** — what appears at the top of the email.
- **Logo** (optional) — ask them to drag the image file into the chat, or give
  you its location, then copy it to the skill's `assets/logo.png`. PNG with a
  transparent background looks best. Any colour works: the logo sits on a white
  header, so dark logos are fine and no light version is needed.
  **Offer this proactively** — most people won't think to mention they have one.
- **Brand colour** — a hex code. If they don't know it, offer to read it from
  their logo, or default to Merit House burgundy `#3D2030`.

Every email carries a Merit House footer regardless of their branding. That's
intentional — don't remove it.

### 5. Save and verify

If they're still waiting on Amazon approval, stop here and tell them so clearly:
everything is saved and ready, and the moment their credentials arrive they can
paste them in and run their first scan. Don't leave them wondering whether setup
"worked."

Write settings with the `config` module, then confirm end to end:

```bash
python3 -c "
import config
config.update(storefront_handle='...', affiliate_tag='...', threshold_pct=25)
"
python3 doctor.py           # must be all PASS
python3 run.py --preview    # sends a sample email so they can see the design
```

Always finish setup with `--preview`. It proves delivery works without waiting
for a real sale, and lets them react to the design immediately.

Then **offer the next step rather than stopping**: once they've seen the preview,
ask whether they want to add a logo or change the colour, and after that whether
they'd like it to run automatically each morning. They will not think to ask.

---

## Before diagnosing "it didn't run" — check whether it's even due

The most common false alarm: someone checks at 7:38am for a run scheduled at
8:00 and concludes it's broken. **Always check the schedule state first.**

```bash
python3 -c "
import config, json
print(json.dumps(config.schedule_status(), indent=2))
"
```

Four possible answers, and each needs a different reply:

- **`not_due_yet`** — say so plainly and offer to run it now anyway:
  *"It's set for 8am and it's 7:38, so it hasn't run yet — want me to run it now
  rather than wait?"* Do not start troubleshooting.
- **`ran_today`** — it already ran; tell them what it found. If they didn't get
  an email, the problem is delivery, not scheduling — check spam, then run the
  check-up.
- **`overdue`** — the computer was probably asleep. Offer to run it now, and
  mention it should catch up on its own next wake.
- **`not_scheduled`** — they never set up a daily run. Offer to.

---

## Check for a dead schedule — do this on every conversation

Sale Scout runs on the creator's own computer, so a scheduled run is skipped
entirely whenever that computer is asleep. The failure is silent: no email, no
error, nothing. A creator can go a week assuming it's working.

**You are the monitoring.** Near the start of any Sale Scout conversation, check
when it last ran:

```bash
python3 -c "
import config
d = config.days_since_last_run()
print('days since last run:', d)
print('last outcome:', config.load().get('last_run_summary'))
"
```

If it's been 2+ days and they have a schedule set up, tell them plainly — don't
wait for them to ask:

> Heads up — Sale Scout hasn't run since Tuesday. That usually means the computer
> was asleep at 8am. Want me to run it now?

Then offer the fix: a desktop that stays on, leaving the laptop open and plugged
in, or scheduling it for a time they're normally working. On Windows, Task
Scheduler can wake the machine; macOS can be set to wake on a schedule in Energy
Saver settings.

---

## Everyday tasks

### Run a scan now

```bash
python3 run.py
```

**Tell them it takes 3–5 minutes before you start it.** It reads every product in
their storefront, then checks prices in batches at Amazon's rate limit.

Add `--dry-run` to show results without sending. Add `--threshold 15` to try a
different cutoff for one run without changing their saved setting.

### Change the threshold

```bash
python3 -c "import config; config.update(threshold_pct=20)"
```

Guidance if they ask: 25% is the default and keeps the email focused. At 15% a
large storefront can produce 40+ items a day, which is a lot to post. If they're
getting too many, raise it; if some days are empty, lower it.

### Mute a product

When they say "stop showing me that cooler," find the ASIN from the most recent
run output or the email, then:

```bash
python3 -c "import config; config.exclude_asin('B0XXXXXXXX')"
```

To mute a whole category of thing — every phone case, say:

```bash
python3 -c "import config; config.exclude_keyword('phone case')"
```

Keyword muting matches anywhere in the product title, so keep it specific. Tell
them what you muted and how many products it affects, and remind them it's
reversible with `unexclude_asin` / `unexclude_keyword`.

To show the current mute list:

```bash
python3 -c "
import config
cfg = config.load()
print('Muted products:', cfg['excluded_asins'])
print('Muted keywords:', cfg['excluded_keywords'])
"
```

### Give them today's links (no copying from email)

Copying links out of an email on a phone is genuinely awkward. Every run saves
its finds, so just hand them over:

```bash
python3 -c "
import config, json
for i in config.load_last_items():
    print(f\"{i['pct_off']}% off  {i['title'][:60]}\")
    print(f\"  {i['deep_link']}\")
"
```

Paste the result straight into the chat — copying from there is easy. **Offer
this whenever they mention posting, copying, or the links.**

### Preview the email design

```bash
python3 run.py --preview
```

Sends a digest with two fake products. Use this after any branding change.

### Schedule the daily run

See `references/scheduling.md` for the exact steps on macOS and Windows.

Before setting it up, tell them the honest constraint: **it only runs when their
computer is awake.** A laptop that's closed at 8am won't send anything. If that's
a problem for them, running it manually when they sit down to plan content works
just as well — the scan is the same either way.

### Check their settings

```bash
python3 -c "import config, json; print(json.dumps(config.redacted(), indent=2))"
```

Use `redacted()`, never `load()`, when displaying settings. It shows secrets only
as a length and prefix, so nothing sensitive ends up on screen or in the
transcript.

---

## When something breaks

**Always run `python3 doctor.py` first.** It tests each link in the chain
separately and names the broken one. Don't guess from symptoms, and don't change
settings before reading its output.

Common cases:

| What they see | Cause | Fix |
|---|---|---|
| "0 products found" | Wrong storefront handle | Re-check the part after `/shop/` |
| `invalid_client` / 401 | Credential ID or Secret wrong or truncated | Re-copy both from Amazon; check the Secret is ~80 chars |
| 400 with a long code | SDK's OAuth scope | `doctor.py` verifies the built-in fix |
| Gmail login rejected | Regular password used | Needs a 16-char App Password + 2-Step Verification |
| Slack `not_in_channel` | Bot not invited | `/invite @BotName` in that channel |
| Nothing arrives, no error | Nothing met the threshold | Normal. Confirm with `--dry-run`, or lower the threshold |

More detail in `references/troubleshooting.md`.

**A note on diagnosing:** the scripts deliberately distinguish "scraped 0
products" from "nothing on sale" from "price checks failed," because these look
identical if you only count results. Trust those messages and read them
carefully — they're specific on purpose.

---

## Privacy

Credentials sit in `~/.sale-scout/config.json` with owner-only permissions. Don't
copy them elsewhere, don't paste them into chat, and don't include them in any
file you create. If a user shares a screenshot containing a secret, tell them to
regenerate it.
