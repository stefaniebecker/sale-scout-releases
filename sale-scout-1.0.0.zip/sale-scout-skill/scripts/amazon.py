"""
Sale Scout — Amazon Creators API.

Takes a list of ASINs, returns the ones currently discounted past a threshold.

The API cannot list a storefront's contents, which is why scrape_storefront.py
exists: scrape the ASINs first, then price them here.
"""

import sys
import time
from dataclasses import dataclass

from creatorsapi_python_sdk import ApiClient, DefaultApi
from creatorsapi_python_sdk.models import GetItemsRequestContent, GetItemsResource

# amazon-creatorsapi-python-sdk 1.0.0 ships an incorrect OAuth2 scope, so Amazon's
# token endpoint rejects every request with HTTP 400. Force the correct one here.
# Do NOT "fix" this by editing the installed package — that edit is lost on the
# next pip install and produces credentials that mysteriously work on one machine
# and fail on another.
try:
    from creatorsapi_python_sdk.auth.oauth2_config import OAuth2Config
    OAuth2Config.SCOPE = "creatorsapi::default"
except (ImportError, AttributeError) as e:  # pragma: no cover
    print(f"WARNING: could not apply the OAuth2 scope patch: {e}", file=sys.stderr)

from deeplink import make_deep_link

LWA_ENDPOINT = "https://api.amazon.com/auth/o2/token"
API_HOST     = "https://creatorsapi.amazon"
MARKETPLACE  = "www.amazon.com"
API_VERSION  = "v3.1"   # only accepted when auth_endpoint is passed explicitly

BATCH_SIZE = 10          # hard API maximum per request
RATE_PAUSE = 0.5         # API allows ~1 request/second

RESOURCES = [
    GetItemsResource.ITEM_INFO_DOT_TITLE,
    GetItemsResource.IMAGES_DOT_PRIMARY_DOT_MEDIUM,
    GetItemsResource.OFFERS_V2_DOT_LISTINGS_DOT_PRICE,
    GetItemsResource.OFFERS_V2_DOT_LISTINGS_DOT_DEAL_DETAILS,
    GetItemsResource.OFFERS_V2_DOT_LISTINGS_DOT_AVAILABILITY,
    GetItemsResource.OFFERS_V2_DOT_LISTINGS_DOT_IS_BUY_BOX_WINNER,
]


@dataclass
class SaleItem:
    asin: str
    title: str
    current_price: float
    original_price: float
    pct_off: int
    deal_type: object
    affiliate_url: str
    deep_link: str
    image_url: object


def build_api(credential_id, credential_secret):
    if not credential_id or not credential_secret:
        raise ValueError("Amazon Credential ID and Client Secret are both required.")
    client = ApiClient(
        host=API_HOST,
        credential_id=credential_id.strip(),
        credential_secret=credential_secret.strip(),
        version=API_VERSION,
        auth_endpoint=LWA_ENDPOINT,
    )
    return DefaultApi(client)


def _batches(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def get_sale_items(api, asins, threshold, partner_tag, stats=None, verbose=True):
    """Return SaleItems at or above `threshold` percent off.

    `stats` (a dict) collects batch success/failure counts. Without it, an
    authentication failure is indistinguishable from "nothing is on sale" —
    both produce an empty list.
    """
    sale_items = []
    total = (len(asins) + BATCH_SIZE - 1) // BATCH_SIZE
    if stats is not None:
        stats.update(batches_ok=0, batches_failed=0, last_error=None)

    for i, batch in enumerate(_batches(asins, BATCH_SIZE), 1):
        if verbose:
            print(f"  Checking prices {i}/{total}...", end=" ", flush=True)
        try:
            request = GetItemsRequestContent(
                partner_tag=partner_tag,
                item_ids=batch,
                resources=RESOURCES,
            )
            response = api.get_items(x_marketplace=MARKETPLACE,
                                     get_items_request_content=request)
        except Exception as e:
            if stats is not None:
                stats["batches_failed"] += 1
                stats["last_error"] = str(e)[:300]
            if verbose:
                print("failed")
            time.sleep(2)
            continue

        if stats is not None:
            stats["batches_ok"] += 1

        items = []
        result = getattr(response, "items_result", None)
        if result:
            items = getattr(result, "items", []) or []

        found = 0
        for item in items:
            sale = _extract_sale(item, threshold)
            if sale:
                sale_items.append(sale)
                found += 1

        if verbose:
            print(f"{found} on sale")
        time.sleep(RATE_PAUSE)

    return sale_items


def _extract_sale(item, threshold):
    """Return a SaleItem if the buy-box listing is discounted enough, else None."""
    offers = getattr(item, "offers_v2", None)
    listings = getattr(offers, "listings", None) if offers else None
    if not listings:
        return None

    buy_box = next((l for l in listings if getattr(l, "is_buy_box_winner", False)), None)
    listing = buy_box or listings[0]

    price_obj = getattr(listing, "price", None)
    if not price_obj:
        return None

    money = getattr(price_obj, "money", None)
    current = getattr(money, "amount", None) if money else None
    if current is None:
        return None

    savings = getattr(price_obj, "savings", None)
    pct_off = getattr(savings, "percentage", None) if savings else None
    if not pct_off or pct_off < threshold:
        return None

    saving_basis = getattr(price_obj, "saving_basis", None)
    basis_money  = getattr(saving_basis, "money", None) if saving_basis else None
    original     = getattr(basis_money, "amount", None) if basis_money else current

    deal = getattr(listing, "deal_details", None)
    deal_type = getattr(deal, "deal_type", None) if deal else None

    title = "Unknown"
    if item.item_info and item.item_info.title:
        title = item.item_info.title.display_value or "Unknown"

    affiliate_url = getattr(item, "detail_page_url", "") or ""

    image_url = None
    if item.images and item.images.primary and item.images.primary.medium:
        image_url = item.images.primary.medium.url

    return SaleItem(
        asin=item.asin,
        title=title,
        current_price=current,
        original_price=original,
        pct_off=pct_off,
        deal_type=str(deal_type) if deal_type else None,
        affiliate_url=affiliate_url,
        deep_link=make_deep_link(affiliate_url),
        image_url=image_url,
    )
