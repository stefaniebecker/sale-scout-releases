"""
Sale Scout — delivery. Branded HTML email via Gmail, and/or Slack.

Both senders RAISE on failure rather than returning False. An earlier version
returned False, callers ignored it, and the run reported success while nothing
was ever delivered. Don't reintroduce that.
"""

import os
import smtplib
import sys
from datetime import date
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587

# Merit House stationery palette — warm off-white paper, burgundy ink, dusty
# blue-grey as the anchor, taupe for secondary text. Airy rather than heavy.
CREAM       = "#F4F2EF"   # paper
WARM_GRAY   = "#DCE3E7"   # pale blue-grey tint
BLUE_GREY   = "#AEBCC4"   # the striped-card blue
TAUPE       = "#7D716B"
TEXT_MUTED  = "#7D716B"
BORDER      = "#E4E0DC"
MH_BURGUNDY = "#3D2030"   # Merit House ink, fixed — not the creator's brand colour
WHITE       = "#FFFFFF"

_LOGO_CID = "creator_logo"
_MH_LOGO_CID = "merit_house_logo"


def _merit_house_logo():
    """Merit House wordmark for the footer, as (bytes, subtype).

    Falls back to a styled text wordmark if the file is absent, so the footer
    never breaks — but ship assets/merit-house-logo.png for the real thing.
    """
    here = os.path.dirname(__file__)
    for name in ("merit-house-logo.png", "merit-house-logo.jpg"):
        path = os.path.abspath(os.path.join(here, "..", "assets", name))
        try:
            with open(path, "rb") as f:
                data = f.read()
            return data, ("jpeg" if name.endswith(".jpg") else "png")
        except (FileNotFoundError, IsADirectoryError, PermissionError):
            continue
    return None, None


def _logo_bytes(cfg=None):
    """The creator's logo, as (bytes, subtype). Returns (None, None) if absent.

    Checks `logo_path` from config first so a creator can point at a file anywhere,
    then falls back to assets/logo.png inside the skill. Missing logo degrades to a
    text header rather than failing — plenty of creators don't have one.
    """
    candidates = []
    if cfg and cfg.get("logo_path"):
        candidates.append(os.path.expanduser(cfg["logo_path"]))
    here = os.path.dirname(__file__)
    for name in ("logo.png", "logo.jpg", "logo.jpeg"):
        candidates.append(os.path.abspath(os.path.join(here, "..", "assets", name)))

    for path in candidates:
        try:
            with open(path, "rb") as f:
                data = f.read()
            subtype = "jpeg" if path.lower().endswith((".jpg", ".jpeg")) else "png"
            return data, subtype
        except (FileNotFoundError, IsADirectoryError, PermissionError):
            continue
    return None, None


def _discount_label(pct_off):
    """Typographic rather than emoji — the emoji read as loud next to a serif
    wordmark and refined stationery palette."""
    if pct_off >= 40:
        return "BEST DEAL TODAY"
    if pct_off >= 25:
        return "GREAT DEAL"
    return "ON SALE"


def _item_html(item, brand_color):
    image = ""
    if item.image_url:
        image = (f'<img src="{item.image_url}" width="104" '
                 f'style="display:block; border-radius:2px;" alt="">')

    return f"""
    <tr><td style="padding:0 0 14px;">
      <table width="100%" cellpadding="0" cellspacing="0"
             style="background:{WHITE}; border:1px solid {BORDER};">
        <tr>
          <td width="140" valign="top" style="padding:22px 18px; text-align:center;">
            {image}
          </td>
          <td valign="top" style="padding:22px 24px 22px 0;
                                  font-family:Georgia,'Times New Roman',serif;">
            <div style="font-family:Helvetica,Arial,sans-serif; font-size:9px;
                        font-weight:700; color:{TAUPE}; letter-spacing:.16em;
                        padding-bottom:9px;">
              {_discount_label(item.pct_off)} &nbsp;·&nbsp; {item.pct_off}% OFF
            </div>
            <div style="font-size:15px; color:#2B2522; line-height:1.4;
                        padding-bottom:10px;">
              {item.title[:92]}
            </div>
            <div style="font-size:19px; color:{brand_color}; padding-bottom:16px;">
              ${item.current_price:.2f}
              <span style="font-family:Helvetica,Arial,sans-serif; font-size:12px;
                           color:{TEXT_MUTED}; text-decoration:line-through;
                           padding-left:8px;">${item.original_price:.2f}</span>
            </div>
            <a href="{item.affiliate_url}"
               style="font-family:Helvetica,Arial,sans-serif; background:{brand_color};
                      color:{WHITE}; text-decoration:none; padding:10px 22px;
                      font-size:11px; font-weight:600; letter-spacing:.1em;
                      display:inline-block;">VIEW ON AMAZON</a>
            <div style="font-family:Helvetica,Arial,sans-serif; font-size:9px;
                        color:{TAUPE}; letter-spacing:.1em; padding-top:16px;">
              DEEP LINK &nbsp;—&nbsp; HOLD TO COPY
            </div>
            <div style="font-family:Menlo,Consolas,monospace; font-size:10px;
                        color:#5A524E; word-break:break-all; padding-top:4px;">
              {item.deep_link}
            </div>
          </td>
        </tr>
      </table>
    </td></tr>"""


def _retailer_html(retailer_sales, brand_color, checked_names=None):
    """Informational 'who else is on sale' block.

    No links at all — retailer sale-page URLs move constantly and a dead link in
    a customer's email is worse than no link. Listing who was checked matters as
    much as the hits: a quiet day should read as "we looked and there was
    nothing", not "this is broken".
    """
    if not retailer_sales and not checked_names:
        return ""

    rows = ""
    for entry in retailer_sales or []:
        name, offer = entry[0], entry[1]
        url = entry[2] if len(entry) > 2 else None
        label = (f'<a href="{url}" style="color:#2B2B2B; text-decoration:none;">{name}</a>'
                 if url else name)
        rows += f"""
        <tr>
          <td style="padding:8px 0; border-bottom:1px solid {BORDER};
                     font-family:Helvetica,Arial,sans-serif; vertical-align:top;">
            <span style="font-size:13px; font-weight:700;">{label}</span>
            <span style="font-size:13px; color:{TEXT_MUTED};"> — {offer}</span>
          </td>
        </tr>"""

    if retailer_sales:
        heading, sub = "ALSO ON SALE TODAY", "Real sales worth posting about — no links, just a heads-up."
        body = f'<table width="100%" cellpadding="0" cellspacing="0">{rows}</table>'
    else:
        heading, sub = "NO OTHER SALES TODAY", "Nothing worth posting at the retailers below right now."
        body = ""

    checked = ""
    if checked_names:
        checked = f"""
              <div style="font-family:Helvetica,Arial,sans-serif; font-size:10px;
                          color:{TEXT_MUTED}; padding-top:14px; line-height:1.6;">
                <strong style="letter-spacing:.04em;">RETAILERS WE CHECKED:</strong>
                {", ".join(checked_names)}
              </div>"""

    return f"""
        <tr><td style="padding:26px 0 0;">
          <table width="100%" cellpadding="0" cellspacing="0"
                 style="background:{WHITE}; border:1px solid {BORDER}; border-radius:6px;">
            <tr><td style="padding:18px 22px;">
              <div style="font-family:Helvetica,Arial,sans-serif; font-size:12px;
                          font-weight:700; color:{brand_color}; letter-spacing:.06em;
                          padding-bottom:4px;">
                {heading}
              </div>
              <div style="font-family:Helvetica,Arial,sans-serif; font-size:11px;
                          color:{TEXT_MUTED}; padding-bottom:10px;">
                {sub}
              </div>
              {body}
              {checked}
            </td></tr>
          </table>
        </td></tr>"""


def build_html(sale_items, brand_name, brand_color, has_logo, threshold,
               has_mh_logo=False, retailer_sales=None, checked_names=None,
               accent_color=None, light_header=True):
    """light_header puts the logo on a soft background with an accent rule under
    it, rather than knocking it out of a heavy solid block. Reads friendlier and
    lets a dark logo sit on it without needing a light version."""
    today = date.today().strftime("%B %d, %Y")
    accent_color = accent_color or WARM_GRAY

    if light_header:
        mark = (f'<img src="cid:{_LOGO_CID}" alt="{brand_name}" width="190" '
                f'style="display:block; margin:0 auto;">' if has_logo else
                f'<span style="font-size:25px; font-weight:700; color:{brand_color}; '
                f'letter-spacing:.04em;">{brand_name}</span>')
        header_block = f"""
        <tr><td style="background:{WHITE}; padding:44px 30px 0; text-align:center;
                       border:1px solid {BORDER}; border-bottom:none;">
          {mark}
          <div style="font-family:Helvetica,Arial,sans-serif; font-size:9px;
                      color:{TAUPE}; padding-top:18px; letter-spacing:.22em;">
            TODAY'S SALES
          </div>
          <div style="font-family:Helvetica,Arial,sans-serif; font-size:9px;
                      color:{TAUPE}; padding-top:5px; letter-spacing:.14em;">
            {today.upper()}
          </div>
          <div style="height:1px; background:{accent_color}; margin:28px 0 0;"></div>
        </td></tr>"""
    else:
        mark = (f'<img src="cid:{_LOGO_CID}" alt="{brand_name}" width="170" '
                f'style="display:block; margin:0 auto;">' if has_logo else
                f'<span style="font-size:22px; font-weight:700; color:{CREAM};">'
                f'{brand_name}</span>')
        header_block = f"""
        <tr><td style="background:{brand_color}; padding:26px 20px; text-align:center;
                       border-radius:6px 6px 0 0;">
          {mark}
          <div style="font-family:Helvetica,Arial,sans-serif; font-size:12px;
                      color:{CREAM}; opacity:.85; padding-top:8px; letter-spacing:.05em;">
            TODAY'S SALES · {today.upper()}
          </div>
        </td></tr>"""

    items_html = "".join(_item_html(i, brand_color) for i in sale_items)

    # Merit House footer mark — real wordmark when the asset is present, styled
    # text otherwise. The tagline only appears in the text version, because the
    # wordmark's own lockup already carries the brand.
    if has_mh_logo:
        mh_mark = (f'<img src="cid:{_MH_LOGO_CID}" alt="Merit House" width="180" '
                   f'style="display:block; margin:0 auto 4px;">')
    else:
        mh_mark = (
            f'<div style="font-size:15px; font-weight:700; color:{MH_BURGUNDY}; '
            f'letter-spacing:.08em;">MERIT HOUSE</div>'
            f'<div style="font-size:12px; color:{TEXT_MUTED}; padding-top:5px; '
            f'line-height:1.5;">The team behind your favorite content creator.</div>'
        )

    return f"""<!DOCTYPE html>
<html><body style="margin:0; padding:0; background:{CREAM};">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:{CREAM}; padding:40px 0;">
    <tr><td align="center">
      <table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;">

        {header_block}

        <tr><td style="background:{WHITE}; border:1px solid {BORDER};
                       border-top:none; border-bottom:none; padding:24px 30px 30px;
                       font-family:Georgia,'Times New Roman',serif; font-size:15px;
                       color:{TAUPE}; text-align:center; line-height:1.5;">
          <span style="color:{brand_color}; font-size:17px;">{len(sale_items)}
          {"item" if len(sale_items) == 1 else "items"}</span>
          from your storefront {"is" if len(sale_items) == 1 else "are"}
          {threshold}% off or more today.
        </td></tr>

        <tr><td style="padding:0;">
          <table width="100%" cellpadding="0" cellspacing="0">{items_html}</table>
        </td></tr>

        {_retailer_html(retailer_sales, brand_color, checked_names)}

        <tr><td style="padding:22px 0 0;">
          <table width="100%" cellpadding="0" cellspacing="0"
                 style="background:{WHITE}; border:1px solid {BORDER}; border-radius:6px;">
            <tr><td style="padding:20px 24px; text-align:center;
                           font-family:Helvetica,Arial,sans-serif;">
              {mh_mark}
              <div style="font-size:12px; color:{TEXT_MUTED}; padding-top:10px;
                          line-height:1.6;">
                Email marketing · SEO &amp; AEO · AI support<br>
                <a href="https://themerithouse.com"
                   style="color:{MH_BURGUNDY}; font-weight:600; text-decoration:none;">
                  themerithouse.com
                </a>
              </div>
            </td></tr>
          </table>
        </td></tr>

        <tr><td style="padding:14px 10px 0; font-family:Helvetica,Arial,sans-serif;
                       font-size:11px; color:{TEXT_MUTED}; text-align:center;">
          Sent by <strong>Sale Scout</strong>, a Merit House product.
        </td></tr>

      </table>
    </td></tr>
  </table>
</body></html>"""


def send_email(sale_items, cfg, retailer_sales=None, checked_names=None):
    """Send the digest. Raises RuntimeError with a plain-English cause on failure."""
    from_address = cfg.get("gmail_address", "")
    app_password = cfg.get("gmail_app_password", "")
    to_address   = cfg.get("alert_email", "")

    if not from_address or not app_password or not to_address:
        raise RuntimeError(
            "Email delivery needs gmail_address, gmail_app_password and alert_email."
        )

    brand_name  = cfg.get("brand_name") or "Your Storefront"
    brand_color = cfg.get("brand_color") or "#3D2030"
    threshold   = cfg.get("threshold_pct", 25)
    today       = date.today().strftime("%B %d, %Y")

    logo_data, logo_subtype = _logo_bytes(cfg)
    has_logo  = logo_data is not None
    mh_data, mh_subtype = _merit_house_logo()
    has_mh_logo = mh_data is not None

    msg_root = MIMEMultipart("related")
    msg_root["Subject"] = (f"{len(sale_items)} "
                           f"{'item' if len(sale_items) == 1 else 'items'} "
                           f"on sale today ({today})")
    msg_root["From"] = f"{brand_name} Sale Scout <{from_address}>"
    msg_root["To"]   = to_address

    msg_alt = MIMEMultipart("alternative")
    msg_root.attach(msg_alt)

    lines = [f"{brand_name} — Today's Sales ({today})", ""]
    for item in sale_items:
        lines.append(f"• {item.title[:80]}")
        lines.append(f"  ${item.current_price:.2f} "
                     f"(was ${item.original_price:.2f}) — {item.pct_off}% off")
        lines.append(f"  Link:      {item.affiliate_url}")
        lines.append(f"  Deep link: {item.deep_link}")
        lines.append("")
    if retailer_sales:
        lines.append("ALSO ON SALE TODAY (no links — just a heads-up)")
        for entry in retailer_sales:
            lines.append(f"  {entry[0]} — {entry[1]}")
            if len(entry) > 2 and entry[2]:
                lines.append(f"    {entry[2]}")
        lines.append("")
    lines.append("—")
    lines.append("Merit House — the team behind your favorite creators.")
    lines.append("Email marketing · SEO & AEO · AI support · themerithouse.com")
    lines.append("Sent by Sale Scout, a Merit House product.")

    msg_alt.attach(MIMEText("\n".join(lines), "plain"))
    msg_alt.attach(MIMEText(
        build_html(sale_items, brand_name, brand_color, has_logo, threshold,
                   has_mh_logo=has_mh_logo, retailer_sales=retailer_sales,
                   checked_names=checked_names), "html"))

    if has_logo:
        logo = MIMEImage(logo_data, _subtype=logo_subtype)
        logo.add_header("Content-ID", f"<{_LOGO_CID}>")
        logo.add_header("Content-Disposition", "inline", filename="logo.png")
        msg_root.attach(logo)

    if has_mh_logo:
        mh = MIMEImage(mh_data, _subtype=mh_subtype)
        mh.add_header("Content-ID", f"<{_MH_LOGO_CID}>")
        mh.add_header("Content-Disposition", "inline", filename="merit-house.png")
        msg_root.attach(mh)

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.login(from_address, app_password)
            smtp.sendmail(from_address, to_address, msg_root.as_string())
    except smtplib.SMTPAuthenticationError:
        raise RuntimeError(
            "Gmail rejected the login. The app password must be the 16-character "
            "code from myaccount.google.com/apppasswords — not your normal Gmail "
            "password. It only works if 2-Step Verification is on."
        )
    except Exception as e:
        raise RuntimeError(f"Could not send the email: {e}")

    return to_address


def send_slack(sale_items, cfg, retailer_sales=None):
    """Post the digest to Slack. Raises RuntimeError on failure."""
    import json
    import urllib.request

    token   = cfg.get("slack_bot_token", "")
    channel = cfg.get("slack_channel", "")
    if not token or not channel:
        raise RuntimeError("Slack delivery needs slack_bot_token and slack_channel.")

    brand = cfg.get("brand_name") or "Your storefront"
    today = date.today().strftime("%B %d, %Y")

    blocks = [{
        "type": "header",
        "text": {"type": "plain_text",
                 "text": f"{len(sale_items)} items on sale — {today}"},
    }]

    for item in sale_items[:40]:   # Slack caps blocks per message
        text = (f"*{item.title[:80]}*\n"
                f"${item.current_price:.2f} ~${item.original_price:.2f}~ "
                f"· *{item.pct_off}% off*\n"
                f"<{item.affiliate_url}|View on Amazon>\n"
                f"`{item.deep_link}`")
        block = {"type": "section", "text": {"type": "mrkdwn", "text": text}}
        if item.image_url:
            block["accessory"] = {"type": "image",
                                  "image_url": item.image_url,
                                  "alt_text": item.title[:40]}
        blocks.append(block)

    if retailer_sales:
        lines = "\n".join(
            f"• *<{e[2]}|{e[0]}>* — {e[1]}" if len(e) > 2 and e[2]
            else f"• *{e[0]}* — {e[1]}" for e in retailer_sales)
        blocks.append({"type": "divider"})
        blocks.append({"type": "section",
                       "text": {"type": "mrkdwn",
                                "text": f"*Also on sale today*\n{lines}"}})

    blocks.append({
        "type": "context",
        "elements": [{"type": "mrkdwn",
                      "text": f"{brand} · Sent by Sale Scout — a Merit House product"}],
    })

    payload = json.dumps({"channel": channel, "blocks": blocks,
                          "text": f"{len(sale_items)} items on sale today"}).encode()
    req = urllib.request.Request(
        "https://slack.com/api/chat.postMessage",
        data=payload,
        headers={"Content-Type": "application/json; charset=utf-8",
                 "Authorization": f"Bearer {token}"},
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = json.loads(resp.read().decode())
    except Exception as e:
        raise RuntimeError(f"Could not reach Slack: {e}")

    if not body.get("ok"):
        err = body.get("error", "unknown error")
        hint = ""
        if err == "not_in_channel":
            hint = " — invite the bot to the channel with /invite @YourBot"
        elif err == "channel_not_found":
            hint = " — check the channel name, and that the bot can see it"
        elif err in ("invalid_auth", "not_authed"):
            hint = " — the bot token looks wrong; it should start with xoxb-"
        raise RuntimeError(f"Slack rejected the message: {err}{hint}")

    return channel
