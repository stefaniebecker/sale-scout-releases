"""Sale Scout version and update settings."""

VERSION = "1.9.6"

# Where update.py looks for a newer release. Publish a zip of the skill folder
# here and every installed copy can pull it with "update Sale Scout".
# The JSON at VERSION_URL should look like:
#   {"version": "1.5.0", "url": "https://.../sale-scout-1.5.0.zip",
#    "notes": "What changed, in one sentence"}
VERSION_URL = ("https://raw.githubusercontent.com/stefaniebecker/"
               "sale-scout-releases/main/latest.json")
