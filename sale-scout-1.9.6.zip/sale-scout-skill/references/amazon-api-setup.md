# Getting your Amazon access

This is the one slow step, and the only one you can't rush. Do it first — Claude
will set up everything else while you wait.

---

## What this actually is

You already have an **Amazon Associates** account — that's how you earn
commission on your storefront.

Sale Scout needs something separate: permission to *ask Amazon about prices*.
Amazon calls this the **Creators API**. It's free, but you have to register for
it and meet their requirements.

(If you've read older guides mentioning the **Product Advertising API**, or
PA-API: that's the same thing under its old name. Amazon has replaced it with
the Creators API and published a deprecation notice for PA-API 5.)

Without it, Sale Scout can see what's in your storefront but can't tell what
anything costs.

---

## ⚠️ The requirement that stops most people

Amazon requires **at least 10 qualifying sales in the past 30 days** before
they'll give you Creators API credentials.

That's their rule, not ours, and there's no way around it. If your storefront
hasn't made 10 sales in the last month, you can't get access yet — make some
sales through your links and come back.

You'll also need to be enrolled in the Amazon Associates program for your
marketplace (the US one, if you're in the States).

---

## Step 1 — Find the Creators API page

This is genuinely hard to find, so here's the exact route. These are the real
clicks, not a description.

1. Go to **amazon.com** and make sure you're signed in
2. In the **top left corner**, click **SiteStripe** — the bar that says
   *Influencers and Associates*
3. That takes you to your Associates home page
   (affiliate-program.amazon.com/home)
4. In the **top right corner**, click the **hamburger menu** — the three
   stacked lines ☰
5. Click **Tools**
6. Click **Creators API** in the dropdown

That's the page. Register for access from there.

**Don't see SiteStripe in step 2?** It only appears when you're signed in to
the Amazon account linked to your Associates account. If it's missing, sign out
and back in, or go straight to **affiliate-program.amazon.com/home** and pick up
from step 4.

Amazon's own instructions, if you want them:
affiliate-program.amazon.com/creatorsapi/docs/en-us/onboarding/register-for-creators-api

### Two things that trip people up

**You have to be the main account holder.** Only the primary owner of the
Amazon Associates account can sign up for the Creators API. If your account is
shared with a partner, assistant or manager, it has to be done from the main
login — not a second user.

**Your Associates account has to be fully accepted.** Not just applied for —
Amazon has to have reviewed it and given final acceptance. Most established
creators have this already. If yours is still provisional, use the Contact Us
form in Associates, explain that you need Creators API access, and ask them to
complete the review.

---

## Step 2 — Generate your two codes

Once you have access, generate a set of API credentials. Amazon gives you two
things:

| What Amazon calls it | What it looks like |
|---|---|
| **Credential ID** | A long code starting `amzn1.application-oa2-client...` |
| **Client Secret** | A long code starting `amzn1.oa2-cs...` |

**Amazon will ask you to name it.** It's just a label for your own records —
nothing depends on it and you can't get it wrong. **Sale Scout** is a fine
answer.

---

## ⚠️ Copy the second code before you close that page

Amazon shows the **Client Secret** one time only. Once you leave that page it's
gone for good and cannot be recovered.

Copy both codes somewhere safe first — a note to yourself, an email to
yourself, anywhere.

If you've already closed it and don't have the Secret, don't worry: delete that
credential set and generate a new one. Just copy both halves this time.

---

## Step 3 — Hand them over safely

**Don't paste the Client Secret into the chat.** It's a real credential, and
anything you type in a chat gets saved to that conversation's history. There's
no need for it to go there at all.

You don't have to set any of this up. Claude does it:

1. **Claude opens a blank document on your screen.** You don't make it, name it
   or save it anywhere — it's already done.
2. **You paste both codes into the middle of it and press Command + S.**
3. **You type `done` in the chat.**

That's the whole thing. Claude reads the file, saves your codes properly, and
deletes the file afterwards. It won't print them back at you — you'll only ever
see the last four characters, so you can check it got the right ones.

Paste order doesn't matter. Neither do labels, blank lines, or the instructions
already in the document. Claude picks the codes out on its own, and nothing
needs tidying up.

Your codes end up in a settings file on your own computer that only you can
read. They are never sent anywhere except Amazon. We never see them.

**Already pasted it into the chat?** Nothing bad happens. But if you want to be
tidy, delete that credential in Amazon and generate a fresh pair — it takes two
minutes.

---

## If something doesn't work

**"Invalid client" or an error mentioning 401**
Usually the second code got cut off when copying. It should be long — around 80
characters. If yours looks short, copy it again.

**A 400 error with a long jumble of letters**
That's a known bug in Amazon's own software kit, and Sale Scout already works
around it. Ask Claude to run the check-up and it'll confirm.

**"I have keys already but they don't work"**
Make sure they're **Creators API** credentials. Keys from other Amazon services
(ones starting `AKIA`) are a different thing and won't work here. Old PA-API
keys may also no longer work, since that API is being retired.

**Amazon says I'm not eligible**
Check the 10-qualifying-sales-in-30-days rule above. That's the usual reason,
and it isn't permanent.
