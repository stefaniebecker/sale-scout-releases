"""
Sale Scout — delivery. Branded HTML email via Gmail, and/or Slack.

Both senders RAISE on failure rather than returning False. An earlier version
returned False, callers ignored it, and the run reported success while nothing
was ever delivered. Don't reintroduce that.
"""

import html as _html
import os
import smtplib
import sys
from datetime import date
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

SMTP_PORT = 587

# Gmail is the common case but plenty of creators are on Outlook or iCloud, and
# requiring Gmail would be a fourth hurdle on top of Amazon, Claude and an
# always-on computer. Work out the mail server from their address instead.
SMTP_HOSTS = {
    "gmail.com": "smtp.gmail.com",      "googlemail.com": "smtp.gmail.com",
    "outlook.com": "smtp-mail.outlook.com", "hotmail.com": "smtp-mail.outlook.com",
    "live.com": "smtp-mail.outlook.com",    "msn.com": "smtp-mail.outlook.com",
    "yahoo.com": "smtp.mail.yahoo.com",
    "icloud.com": "smtp.mail.me.com",   "me.com": "smtp.mail.me.com",
    "mac.com": "smtp.mail.me.com",
}


def smtp_host_for(address, override=""):
    """Mail server for a sending address. A custom domain usually means Google
    Workspace, so Gmail's server is the right default guess."""
    if override:
        return override
    domain = (address or "").split("@")[-1].lower().strip()
    return SMTP_HOSTS.get(domain, "smtp.gmail.com")

# Merit House stationery palette — warm off-white paper, burgundy ink, dusty
# blue-grey as the anchor, taupe for secondary text. Airy rather than heavy.
# Default palette, taken from the Sale Scout brand: warm paper, slate blue-grey,
# bronze accents, dark slate ink. A creator's own brand colour overrides the
# accent; everything else stays, so an un-branded install still looks designed.
CREAM       = "#EFEBE6"   # page / paper
CARD        = "#FAF9F7"   # card surface
WARM_GRAY   = "#E5E0DA"
SLATE       = "#8FA0AA"   # blue-grey
BRONZE      = "#9A8469"   # badge fill
TAUPE       = "#8A8178"
TEXT_MUTED  = "#8A8178"
INK         = "#3D4852"
BORDER      = "#E5E0DA"
MH_BURGUNDY = "#3D2030"   # Merit House ink, fixed — not the creator's brand colour
WHITE       = "#FFFFFF"

_LOGO_CID = "creator_logo"
_MH_LOGO_CID = "merit_house_logo"
_CM_LOGO_CID = "car_mom_logo"


def _merit_house_logo():
    """Merit House wordmark for the footer, as (bytes, subtype).

    Falls back to a styled text wordmark if the file is absent, so the footer
    never breaks — but ship assets/merit-house-logo.png for the real thing.
    """
    here = os.path.dirname(__file__)
    for name in ("merit-house-logo.png", "merit-house-logo.jpg"):
        path = os.path.abspath(os.path.join(here, "..", "assets", name))
        try:
            with open(path, "rb") as f:
                data = f.read()
            return data, ("jpeg" if name.endswith(".jpg") else "png")
        except (FileNotFoundError, IsADirectoryError, PermissionError):
            continue
    return None, None


def _car_mom_logo():
    """The Car Mom wordmark for the co-creator footer, as (bytes, subtype)."""
    here = os.path.dirname(__file__)
    for name in ("car-mom-logo.png", "car-mom-logo.jpg"):
        path = os.path.abspath(os.path.join(here, "..", "assets", name))
        try:
            with open(path, "rb") as f:
                data = f.read()
            return data, ("jpeg" if name.endswith(".jpg") else "png")
        except (FileNotFoundError, IsADirectoryError, PermissionError):
            continue
    return None, None


def _logo_bytes(cfg=None):
    """The creator's logo, as (bytes, subtype). Returns (None, None) if absent.

    Checks `logo_path` from config first so a creator can point at a file anywhere,
    then falls back to assets/logo.png inside the skill. Missing logo degrades to a
    text header rather than failing — plenty of creators don't have one.
    """
    candidates = []
    if cfg and cfg.get("logo_path"):
        candidates.append(os.path.expanduser(cfg["logo_path"]))
    here = os.path.dirname(__file__)
    for name in ("logo.png", "logo.jpg", "logo.jpeg"):
        candidates.append(os.path.abspath(os.path.join(here, "..", "assets", name)))

    for path in candidates:
        try:
            with open(path, "rb") as f:
                data = f.read()
            subtype = "jpeg" if path.lower().endswith((".jpg", ".jpeg")) else "png"
            return data, subtype
        except (FileNotFoundError, IsADirectoryError, PermissionError):
            continue
    return None, None


def _discount_label(pct_off):
    """Typographic rather than emoji — the emoji read as loud next to a serif
    wordmark and refined stationery palette."""
    if pct_off >= 40:
        return "BEST DEAL TODAY"
    if pct_off >= 25:
        return "GREAT DEAL"
    return "ON SALE"


def _item_html(item, brand_color):
    """One product row.

    Rounded corners and pill badges to match the Sale Scout brand. Kept on
    tables with inline styles so it survives every mail client — border-radius
    simply degrades to square corners in old Outlook rather than breaking.
    """
    image = ""
    if item.image_url:
        image = (f'<img src="{item.image_url}" width="96" '
                 f'style="display:block; border-radius:10px;" alt="">')

    return f"""
    <tr><td style="padding:0 0 12px;">
      <table width="100%" cellpadding="0" cellspacing="0"
             style="background:{WHITE}; border-radius:16px;">
        <tr>
          <td width="128" valign="top" style="padding:20px 12px 20px 20px;">
            {image}
          </td>
          <td valign="top" style="padding:20px 20px 20px 4px;
                                  font-family:-apple-system,'Segoe UI',Helvetica,Arial,sans-serif;">
            <div style="font-size:15px; font-weight:600; color:{INK};
                        line-height:1.35; padding-bottom:8px;">
              {item.title[:88]}
            </div>
            <div style="padding-bottom:14px;">
              <span style="font-size:13px; color:{TEXT_MUTED};
                           text-decoration:line-through;">${item.original_price:.2f}</span>
              <span style="font-size:17px; font-weight:700; color:{INK};
                           padding-left:7px;">${item.current_price:.2f}</span>
              <span style="display:inline-block; background:{BRONZE}; color:{WHITE};
                           font-size:11px; font-weight:700; border-radius:20px;
                           padding:5px 13px; margin-left:9px; letter-spacing:.03em;">
                {item.pct_off}% OFF
              </span>
            </div>
            <a href="{item.affiliate_url}"
               style="background:{brand_color}; color:{WHITE}; text-decoration:none;
                      padding:10px 20px; font-size:12px; font-weight:600;
                      border-radius:22px; display:inline-block;">View on Amazon</a>
            <div style="font-family:Menlo,Consolas,monospace; font-size:10px;
                        word-break:break-all; padding-top:14px; color:{TEXT_MUTED};">
              {_html.escape(item.affiliate_url)}
            </div>
          </td>
        </tr>
      </table>
    </td></tr>"""


def _retailer_html(retailer_sales, brand_color, checked_names=None):
    """Informational 'who else is on sale' block.

    No links at all — retailer sale-page URLs move constantly and a dead link in
    a customer's email is worse than no link. Listing who was checked matters as
    much as the hits: a quiet day should read as "we looked and there was
    nothing", not "this is broken".
    """
    if not retailer_sales and not checked_names:
        return ""

    rows = ""
    for entry in retailer_sales or []:
        name, offer = entry[0], entry[1]
        url = entry[2] if len(entry) > 2 else None
        label = (f'<a href="{url}" style="color:#2B2B2B; text-decoration:none;">{name}</a>'
                 if url else name)
        rows += f"""
        <tr>
          <td style="padding:8px 0; border-bottom:1px solid {BORDER};
                     font-family:Helvetica,Arial,sans-serif; vertical-align:top;">
            <span style="font-size:13px; font-weight:700;">{label}</span>
            <span style="font-size:13px; color:{TEXT_MUTED};"> — {offer}</span>
          </td>
        </tr>"""

    if retailer_sales:
        heading, sub = "ALSO ON SALE TODAY", "Real sales worth posting about — no links, just a heads-up."
        body = f'<table width="100%" cellpadding="0" cellspacing="0">{rows}</table>'
    else:
        heading, sub = "NO OTHER SALES TODAY", "Nothing worth posting at the retailers below right now."
        body = ""

    checked = ""
    if checked_names:
        checked = f"""
              <div style="font-family:Helvetica,Arial,sans-serif; font-size:10px;
                          color:{TEXT_MUTED}; padding-top:14px; line-height:1.6;">
                <strong style="letter-spacing:.04em;">RETAILERS WE CHECKED:</strong>
                {", ".join(checked_names)}
              </div>"""

    return f"""
        <tr><td style="padding:26px 0 0;">
          <table width="100%" cellpadding="0" cellspacing="0"
                 style="background:{WHITE}; border-radius:16px;">
            <tr><td style="padding:18px 22px;">
              <div style="font-family:Helvetica,Arial,sans-serif; font-size:12px;
                          font-weight:700; color:{brand_color}; letter-spacing:.06em;
                          padding-bottom:4px;">
                {heading}
              </div>
              <div style="font-family:Helvetica,Arial,sans-serif; font-size:11px;
                          color:{TEXT_MUTED}; padding-bottom:10px;">
                {sub}
              </div>
              {body}
              {checked}
            </td></tr>
          </table>
        </td></tr>"""


def build_html(sale_items, brand_name, brand_color, has_logo, threshold,
               has_mh_logo=False, has_cm_logo=False, retailer_sales=None, checked_names=None,
               accent_color=None, light_header=True, late_note=None,
               products_checked=None, update_note=None):
    """light_header puts the logo on a soft background with an accent rule under
    it, rather than knocking it out of a heavy solid block. Reads friendlier and
    lets a dark logo sit on it without needing a light version."""
    today = date.today().strftime("%B %d, %Y")

    accent_color = accent_color or WARM_GRAY

    SANS = "-apple-system,'Segoe UI',Helvetica,Arial,sans-serif"
    # A scheduled run never talks to Claude, so without this a creator can sit
    # on a broken version forever. The daily email is the one thing they read.
    update_banner = ""
    if update_note:
        update_banner = (
            f'<tr><td style="padding:14px 0 0;">'
            f'<table width="100%" cellpadding="0" cellspacing="0" '
            f'style="background:{CREAM}; border-radius:14px;">'
            f'<tr><td style="padding:14px 20px; font-family:{SANS}; '
            f'font-size:12px; color:{INK}; line-height:1.55;">'
            f'<strong>A new version of Sale Scout is ready.</strong><br>'
            f'<span style="color:{TEXT_MUTED};">'
            f'Open Claude Code and say &ldquo;update Sale Scout&rdquo;. '
            f'It takes about thirty seconds and keeps all your settings.'
            f'</span>'
            f'</td></tr></table></td></tr>')
    count = len(sale_items)

    # Logo if they have one, otherwise the brand name set in bold sans. It used
    # to inherit the body serif, which looked like a mistake.
    mark = (f'<img src="cid:{_LOGO_CID}" alt="{brand_name}" width="180" '
            f'style="display:block; margin:0 auto;">' if has_logo else
            f'<div style="font-family:{SANS}; font-size:26px; font-weight:700; '
            f'color:{INK}; letter-spacing:-.02em;">{brand_name}</div>')

    # Header and headline live in ONE card. As two stacked cards they left a
    # visible seam and the date rule read as a stray line.
    header_block = f"""
        <tr><td style="background:{WHITE}; padding:36px 28px 34px; text-align:center;
                       border-radius:18px;">
          {mark}
          <div style="font-family:{SANS}; font-size:34px; font-weight:700;
                      color:{INK}; line-height:1.15; padding-top:26px;">
            {count} deal{"" if count == 1 else "s"} worth posting today
          </div>
          <div style="font-family:{SANS}; font-size:13px; color:{TAUPE};
                      padding-top:8px; line-height:1.5;">
            {products_checked or "Your"} storefront products checked
            &nbsp;·&nbsp; {threshold}% off or more
          </div>
          <div style="font-family:{SANS}; font-size:10px; color:{TAUPE};
                      padding-top:14px; letter-spacing:.16em;">
            {today.upper()}
          </div>
          {f'<div style="font-family:{SANS}; font-size:11px; color:{TAUPE}; padding-top:10px; font-style:italic;">{late_note}</div>' if late_note else ''}
        </td></tr>
        {update_banner}
        <tr><td style="height:14px; line-height:14px; font-size:0;">&nbsp;</td></tr>"""

    items_html = "".join(_item_html(i, brand_color) for i in sale_items)

    # Both wordmarks, matched on height rather than width — they have different
    # proportions (4.1:1 and 5.9:1), so equal widths would make one look larger.
    # Falls back to names in text if either asset is missing.
    SANS_F = "-apple-system,'Segoe UI',Helvetica,Arial,sans-serif"

    cm_img = (f'<img src="cid:{_CM_LOGO_CID}" alt="The Car Mom" width="178" '
              f'style="display:block;">' if has_cm_logo else
              f'<div style="font-family:{SANS_F}; font-size:13px; font-weight:700; '
              f'color:{MH_BURGUNDY};">The Car Mom</div>')

    mh_img = (f'<img src="cid:{_MH_LOGO_CID}" alt="Merit House" width="124" '
              f'style="display:block;">' if has_mh_logo else
              f'<div style="font-family:{SANS_F}; font-size:13px; font-weight:700; '
              f'color:{MH_BURGUNDY};">Merit House</div>')

    mh_mark = (
        f'<div style="font-family:{SANS_F}; font-size:10px; color:{TEXT_MUTED}; '
        f'letter-spacing:.18em; padding-bottom:18px;">CREATED BY</div>'

        f'<table cellpadding="0" cellspacing="0" style="margin:0 auto;"><tr>'

        f'<td align="center" valign="middle" style="padding:0 22px 0 0;">{cm_img}'
        f'<div style="font-family:{SANS_F}; font-size:10px; color:{TEXT_MUTED}; '
        f'padding-top:7px;">Kelly Stumpe &nbsp;·&nbsp; '
        f'<a href="https://www.instagram.com/the_car_mom/" '
        f'style="color:{TEXT_MUTED}; text-decoration:none;">@the_car_mom</a></div></td>'

        f'<td style="width:1px; background:{BORDER}; font-size:0;">&nbsp;</td>'

        f'<td align="center" valign="middle" style="padding:0 0 0 22px;">{mh_img}'
        f'<div style="font-family:{SANS_F}; font-size:10px; color:{TEXT_MUTED}; '
        f'padding-top:7px;">Stefanie Becker &nbsp;·&nbsp; '
        f'<a href="https://www.instagram.com/merithouse_/" '
        f'style="color:{TEXT_MUTED}; text-decoration:none;">@merithouse_</a></div></td>'

        f'</tr></table>'
    )

    return f"""<!DOCTYPE html>
<html><body style="margin:0; padding:0; background:{CREAM};">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:{CREAM}; padding:40px 0;">
    <tr><td align="center">
      <table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;">

        {header_block}

        <tr><td style="padding:0;">
          <table width="100%" cellpadding="0" cellspacing="0">{items_html}</table>
        </td></tr>

        {_retailer_html(retailer_sales, brand_color, checked_names)}

        <tr><td style="padding:22px 0 0;">
          <table width="100%" cellpadding="0" cellspacing="0"
                 style="background:{WHITE}; border-radius:16px;">
            <tr><td style="padding:20px 24px; text-align:center;
                           font-family:Helvetica,Arial,sans-serif;">
              {mh_mark}
              <div style="font-family:-apple-system,'Segoe UI',Helvetica,Arial,sans-serif;
                          font-size:11px; color:{TEXT_MUTED}; padding-top:18px;">
                <a href="https://themerithouse.com"
                   style="color:{MH_BURGUNDY}; font-weight:600; text-decoration:none;">
                  themerithouse.com
                </a>
              </div>
            </td></tr>
          </table>
        </td></tr>

        <tr><td style="padding:14px 10px 0; font-family:Helvetica,Arial,sans-serif;
                       font-size:11px; color:{TEXT_MUTED}; text-align:center;">
          Sent by <strong>Sale Scout</strong>, a Merit House product.
        </td></tr>

      </table>
    </td></tr>
  </table>
</body></html>"""


def send_email(sale_items, cfg, retailer_sales=None, checked_names=None,
               late_note=None, products_checked=None, update_note=None):
    """Send the digest. Raises RuntimeError with a plain-English cause on failure."""
    from_address = cfg.get("gmail_address", "")
    app_password = cfg.get("gmail_app_password", "")
    to_address   = cfg.get("alert_email", "")

    if not from_address or not app_password or not to_address:
        raise RuntimeError(
            "Email delivery needs gmail_address, gmail_app_password and alert_email."
        )

    brand_name  = cfg.get("brand_name") or "Your Storefront"
    brand_color = cfg.get("brand_color") or "#3D2030"
    threshold   = cfg.get("threshold_pct", 25)
    today       = date.today().strftime("%B %d, %Y")

    logo_data, logo_subtype = _logo_bytes(cfg)
    has_logo  = logo_data is not None
    mh_data, mh_subtype = _merit_house_logo()
    has_mh_logo = mh_data is not None
    cm_data, cm_sub = _car_mom_logo()
    has_cm_logo = cm_data is not None

    msg_root = MIMEMultipart("related")
    msg_root["Subject"] = (f"{len(sale_items)} "
                           f"{'item' if len(sale_items) == 1 else 'items'} "
                           f"on sale today ({today})")
    msg_root["From"] = f"{brand_name} Sale Scout <{from_address}>"
    msg_root["To"]   = to_address

    msg_alt = MIMEMultipart("alternative")
    msg_root.attach(msg_alt)

    lines = [f"{brand_name} — Today's Sales ({today})", ""]
    for item in sale_items:
        lines.append(f"• {item.title[:80]}")
        lines.append(f"  ${item.current_price:.2f} "
                     f"(was ${item.original_price:.2f}) — {item.pct_off}% off")
        lines.append(f"  Link:      {item.affiliate_url}")
        lines.append(f"  Link: {item.affiliate_url}")
        lines.append("")
    if retailer_sales:
        lines.append("ALSO ON SALE TODAY (no links — just a heads-up)")
        for entry in retailer_sales:
            lines.append(f"  {entry[0]} — {entry[1]}")
            if len(entry) > 2 and entry[2]:
                lines.append(f"    {entry[2]}")
        lines.append("")
    lines.append("—")
    lines.append("Merit House — the team behind your favorite creators.")
    lines.append("Email marketing · SEO & AEO · AI support · themerithouse.com")
    if update_note:
        lines.append("")
        lines.append("A new version of Sale Scout is ready. Open Claude Code "
                     "and say \u201cupdate Sale Scout\u201d.")
    lines.append("")
    lines.append("Sent by Sale Scout, a Merit House product.")

    msg_alt.attach(MIMEText("\n".join(lines), "plain"))
    msg_alt.attach(MIMEText(
        build_html(sale_items, brand_name, brand_color, has_logo, threshold,
                   has_mh_logo=has_mh_logo, has_cm_logo=has_cm_logo,
                   retailer_sales=retailer_sales,
                   checked_names=checked_names, late_note=late_note,
                   products_checked=products_checked,
                   update_note=update_note), "html"))

    if has_logo:
        logo = MIMEImage(logo_data, _subtype=logo_subtype)
        logo.add_header("Content-ID", f"<{_LOGO_CID}>")
        logo.add_header("Content-Disposition", "inline", filename="logo.png")
        msg_root.attach(logo)

    if has_mh_logo:
        mh = MIMEImage(mh_data, _subtype=mh_subtype)
        mh.add_header("Content-ID", f"<{_MH_LOGO_CID}>")
        mh.add_header("Content-Disposition", "inline", filename="merit-house.png")
        msg_root.attach(mh)

    if has_cm_logo:
        cm = MIMEImage(cm_data, _subtype=cm_sub)
        cm.add_header("Content-ID", f"<{_CM_LOGO_CID}>")
        cm.add_header("Content-Disposition", "inline", filename="the-car-mom.png")
        msg_root.attach(cm)

    try:
        host = smtp_host_for(from_address, cfg.get("smtp_host", "") if cfg else "")
        with smtplib.SMTP(host, SMTP_PORT) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.login(from_address, app_password)
            smtp.sendmail(from_address, to_address, msg_root.as_string())
    except smtplib.SMTPAuthenticationError:
        raise RuntimeError(
            "Gmail rejected the login. The app password must be the 16-character "
            "code from myaccount.google.com/apppasswords — not your normal Gmail "
            "password. It only works if 2-Step Verification is on."
        )
    except Exception as e:
        raise RuntimeError(f"Could not send the email: {e}")

    return to_address


def send_slack(sale_items, cfg, retailer_sales=None, late_note=None):
    """Post the digest to Slack. Raises RuntimeError on failure."""
    import json
    import urllib.request

    token   = cfg.get("slack_bot_token", "")
    channel = cfg.get("slack_channel", "")
    if not token or not channel:
        raise RuntimeError("Slack delivery needs slack_bot_token and slack_channel.")

    brand = cfg.get("brand_name") or "Your storefront"
    today = date.today().strftime("%B %d, %Y")

    if late_note:
        blocks_prefix = [{"type": "context",
                          "elements": [{"type": "mrkdwn", "text": late_note}]}]
    else:
        blocks_prefix = []

    blocks = [{
        "type": "header",
        "text": {"type": "plain_text",
                 "text": f"{len(sale_items)} items on sale — {today}"},
    }]

    for item in sale_items[:40]:   # Slack caps blocks per message
        text = (f"*{item.title[:80]}*\n"
                f"${item.current_price:.2f} ~${item.original_price:.2f}~ "
                f"· *{item.pct_off}% off*\n"
                f"<{item.affiliate_url}|View on Amazon>\n"
                f"`{item.affiliate_url}`")
        block = {"type": "section", "text": {"type": "mrkdwn", "text": text}}
        if item.image_url:
            block["accessory"] = {"type": "image",
                                  "image_url": item.image_url,
                                  "alt_text": item.title[:40]}
        blocks.append(block)

    if retailer_sales:
        lines = "\n".join(
            f"• *<{e[2]}|{e[0]}>* — {e[1]}" if len(e) > 2 and e[2]
            else f"• *{e[0]}* — {e[1]}" for e in retailer_sales)
        blocks.append({"type": "divider"})
        blocks.append({"type": "section",
                       "text": {"type": "mrkdwn",
                                "text": f"*Also on sale today*\n{lines}"}})

    blocks.append({
        "type": "context",
        "elements": [{"type": "mrkdwn",
                      "text": f"{brand} · Sent by Sale Scout — a Merit House product"}],
    })

    blocks = blocks_prefix + blocks
    payload = json.dumps({"channel": channel, "blocks": blocks,
                          "text": f"{len(sale_items)} items on sale today"}).encode()
    req = urllib.request.Request(
        "https://slack.com/api/chat.postMessage",
        data=payload,
        headers={"Content-Type": "application/json; charset=utf-8",
                 "Authorization": f"Bearer {token}"},
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = json.loads(resp.read().decode())
    except Exception as e:
        raise RuntimeError(f"Could not reach Slack: {e}")

    if not body.get("ok"):
        err = body.get("error", "unknown error")
        hint = ""
        if err == "not_in_channel":
            hint = " — invite the bot to the channel with /invite @YourBot"
        elif err == "channel_not_found":
            hint = " — check the channel name, and that the bot can see it"
        elif err in ("invalid_auth", "not_authed"):
            hint = " — the bot token looks wrong; it should start with xoxb-"
        raise RuntimeError(f"Slack rejected the message: {err}{hint}")

    return channel
