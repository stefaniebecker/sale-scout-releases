"""
Sale Scout — main run. Scan the storefront, find today's sales, deliver them.

    python3 run.py                  scan and deliver
    python3 run.py --dry-run        scan and print, deliver nothing
    python3 run.py --threshold 15   override today's threshold
    python3 run.py --preview        send a sample email with fake products

Every failure mode prints a specific cause. "0 items" is never allowed to be
ambiguous: it always says whether the scrape worked, whether the price checks
worked, and how many products were muted.
"""

import argparse
import sys

import config

# Imported behind a guard so a fresh install reports what's missing in plain
# English instead of dumping a ModuleNotFoundError traceback at the user.
try:
    from amazon import build_api, get_sale_items, SaleItem
    from scrape_storefront import scrape_storefront
    import notify
except ImportError as e:
    missing = str(e).split("'")[1] if "'" in str(e) else str(e)
    package = {
        "creatorsapi_python_sdk": "amazon-creatorsapi-python-sdk",
        "playwright": "playwright",
    }.get(missing, missing)
    print("Sale Scout isn't quite finished setting up.\n", file=sys.stderr)
    print("Just ask Claude to finish setting up Sale Scout and it'll sort "
          "this out for you.\n", file=sys.stderr)
    print(f"(For Claude: pip3 install {package}"
          + ("; python3 -m playwright install chromium" if package == "playwright" else "")
          + ")", file=sys.stderr)
    sys.exit(1)


def _deliver(sale_items, cfg, retailer_sales=None, checked_names=None,
             late_note=None, products_checked=None, update_note=None):
    """Send via every configured channel. Returns a list of human-readable results."""
    results = []
    errors = []

    if cfg.get("deliver_to_email"):
        try:
            sent_to = notify.send_email(sale_items, cfg, retailer_sales,
                                        checked_names, late_note,
                                        products_checked=products_checked,
                                        update_note=update_note)
            results.append(f"Emailed to {sent_to}")
        except Exception as e:
            errors.append(f"Email failed: {e}")

    if cfg.get("deliver_to_slack"):
        try:
            results.append(
                f"Posted to Slack {notify.send_slack(sale_items, cfg, retailer_sales, late_note)}")
        except Exception as e:
            errors.append(f"Slack failed: {e}")

    return results, errors


def _update_available():
    """
    Is there a newer Sale Scout? Returns True, or False on any problem.

    A scheduled run never involves Claude, so without this a creator can sit on
    a broken version indefinitely — nothing would ever tell them. This is one
    small HTTPS request, and every failure mode is swallowed: a missed notice
    is a nuisance, a missed digest is the product not working.
    """
    try:
        import update
        return update.check() is not None
    except Exception:
        return False


def preview(cfg):
    """Send a sample digest so the creator can see the design before a real sale."""
    samples = [
        SaleItem(asin="B0SAMPLE01",
                 title="Sample Product — Insulated Travel Mug, 20 oz",
                 current_price=23.99, original_price=39.99, pct_off=40,
                 deal_type="Deal", affiliate_url="https://www.amazon.com/dp/B0SAMPLE01",
                 image_url=None),
        SaleItem(asin="B0SAMPLE02",
                 title="Sample Product — Weighted Blanket, 15 lb",
                 current_price=48.00, original_price=72.00, pct_off=33,
                 deal_type=None, affiliate_url="https://www.amazon.com/dp/B0SAMPLE02",
                 image_url=None),
    ]
    # Include sample retailer sales. Without them the preview silently hides a
    # whole section of the email, which makes it useless for checking the design.
    sample_retailers = [
        ("Target", "40% Off Matching Pajamas For All"),
        ("LOFT", "40% off your purchase"),
        ("Old Navy", "50% Off All Disney Styles"),
    ]
    sample_checked = ["Target", "Anthropologie", "Athleta", "Nordstrom", "Old Navy",
                      "Abercrombie & Fitch", "Zara", "Gap", "Banana Republic",
                      "Spanx", "LOFT", "Quince"]
    results, errors = _deliver(samples, cfg, sample_retailers, sample_checked)
    for r in results:
        print(f"  {r}")
    for e in errors:
        print(f"  {e}", file=sys.stderr)
    if errors and not results:
        sys.exit(1)
    print("\nThis was a preview with fake products, so you can check the design.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true",
                        help="Scan and print results without sending anything")
    parser.add_argument("--threshold", type=int, default=None,
                        help="Override the saved discount threshold for this run")
    parser.add_argument("--preview", action="store_true",
                        help="Send a sample digest with fake products")
    parser.add_argument("--quiet", action="store_true",
                        help="Less output (useful for scheduled runs)")
    parser.add_argument("--once-daily", action="store_true",
                        help="Exit if a run already completed today (for catch-up "
                             "schedulers that fire missed jobs on wake)")
    args = parser.parse_args()

    cfg = config.load()

    if args.preview:
        print("Sending a preview digest...")
        preview(cfg)
        return

    if args.once_daily and config.already_ran_today(cfg):
        if not args.quiet:
            print("Already ran today — skipping.")
        return

    missing = config.missing_fields(cfg)
    if missing:
        # A scheduled run writes to a log file nobody reads, so an unfinished
        # setup is silent by default. Remind them instead — on the desktop and
        # by email, from this same schedule, without ever calling Claude.
        try:
            import nudge
            nudge.remind(verbose=not args.quiet)
        except Exception as e:
            print(f"(reminder skipped: {str(e)[:80]})", file=sys.stderr)

        print("Sale Scout isn't set up yet. Still needed:", file=sys.stderr)
        for m in missing:
            print(f"  - {m}", file=sys.stderr)
        print("\nAsk Claude to finish your Sale Scout setup.", file=sys.stderr)
        sys.exit(1)

    threshold = args.threshold if args.threshold is not None else cfg["threshold_pct"]
    verbose = not args.quiet

    # Permissions drift, leftover handover files, the yearly rotation nudge.
    # Wrapped because none of it is worth losing a digest over.
    try:
        import security
        security.housekeeping(verbose=verbose)
    except Exception:
        pass

    # ── 1. Scrape the storefront ──────────────────────────────────────────────
    handle = cfg["storefront_handle"]
    if verbose:
        print(f"Scanning amazon.com/shop/{handle} — this takes a few minutes...")

    try:
        asins = scrape_storefront(handle, verbose=verbose)
    except Exception as e:
        print(f"\nCouldn't read your storefront: {e}", file=sys.stderr)
        print("If this keeps happening, run: python3 doctor.py", file=sys.stderr)
        sys.exit(1)

    if not asins:
        print(f"\nFound 0 products at amazon.com/shop/{handle}.", file=sys.stderr)
        print("Usually the storefront handle is wrong. It's the part of your "
              "storefront URL after /shop/.", file=sys.stderr)
        sys.exit(1)

    # Compare against the best previous scrape. A sudden collapse means Amazon
    # served a bad page, not that the storefront emptied out.
    typical = cfg.get("typical_product_count", 0)
    if typical >= 20 and len(asins) < typical * 0.5:
        msg = (f"Only found {len(asins)} products, but this storefront normally has "
               f"around {typical}. Amazon likely served an incomplete page.")
        print(f"\n{msg}", file=sys.stderr)
        print("Nothing was sent, to avoid a misleading digest. "
              "Try again in a few minutes.", file=sys.stderr)
        config.record_run(msg)
        sys.exit(1)

    if len(asins) > typical:
        config.update(typical_product_count=len(asins))

    if verbose:
        print(f"\nFound {len(asins)} products. Checking prices...")

    # ── 2. Price check ────────────────────────────────────────────────────────
    stats = {}
    api = build_api(cfg["amazon_credential_id"], cfg["amazon_client_secret"])
    sale_items = get_sale_items(api, asins, threshold,
                                partner_tag=cfg["affiliate_tag"],
                                stats=stats, verbose=verbose)

    if stats.get("batches_ok") == 0 and stats.get("batches_failed", 0) > 0:
        print(f"\nAll {stats['batches_failed']} price checks failed, so Sale Scout "
              f"couldn't tell what's discounted.", file=sys.stderr)
        print(f"Amazon said: {stats.get('last_error')}", file=sys.stderr)
        print("\nThis is almost always the Amazon Credential ID or Client Secret. "
              "Run: python3 doctor.py", file=sys.stderr)
        sys.exit(1)

    # ── 3. Apply the mute list ────────────────────────────────────────────────
    before = len(sale_items)
    sale_items = [i for i in sale_items if not config.is_excluded(i.asin, i.title, cfg)]
    muted = before - len(sale_items)

    sale_items.sort(key=lambda x: x.pct_off, reverse=True)
    config.save_last_items(sale_items)

    # ── 3b. Who else is on sale (informational, no affiliate links) ───────────
    retailer_sales = []
    checked_names = []
    if cfg.get("check_retailers", True):
        if verbose:
            print("\nChecking other retailers...")
        try:
            from retailers import check_retailers, RETAILERS
            retailer_sales = check_retailers(verbose=verbose)
            checked_names = [n for n, _ in RETAILERS]
        except Exception as e:
            # Never let this optional extra break the Amazon digest.
            print(f"  (retailer check skipped: {str(e)[:80]})", file=sys.stderr)

    # ── 4. Report and deliver ─────────────────────────────────────────────────
    print(f"\nChecked {len(asins)} products. "
          f"{len(sale_items)} at {threshold}%+ off"
          + (f" ({muted} muted)." if muted else "."))

    if stats.get("batches_failed"):
        print(f"Note: {stats['batches_failed']} price checks failed and were skipped.")

    if not sale_items and not retailer_sales:
        print("Nothing to send today.")
        config.record_run(f"Checked {len(asins)} products. Nothing at {threshold}%+ off.")
        return

    if not sale_items and retailer_sales:
        print(f"No Amazon items at {threshold}%+ off, but "
              f"{len(retailer_sales)} retailer(s) are running sales — sending those.")

    for item in sale_items:
        print(f"  {item.pct_off:>3}% off  ${item.current_price:>8.2f}  "
              f"{item.title[:60]}  [{item.asin}]")

    if args.dry_run:
        print("\nDry run — nothing was sent.")
        return

    print()
    # If the computer was asleep at the scheduled time, say so in the email —
    # otherwise a digest arriving at lunchtime just looks unreliable.
    late_note = None
    sched_h = cfg.get("scheduled_hour")
    if sched_h is not None:
        from datetime import datetime
        now = datetime.now()
        due = now.replace(hour=int(sched_h), minute=int(cfg.get("scheduled_minute", 0) or 0),
                          second=0, microsecond=0)
        if (now - due).total_seconds() > 1800:
            late_note = (f"Your computer was asleep at {due.strftime('%-I:%M %p')}, "
                         f"so this ran at {now.strftime('%-I:%M %p')} instead.")

    results, errors = _deliver(sale_items, cfg, retailer_sales, checked_names,
                               late_note, products_checked=len(asins),
                               update_note=_update_available())
    for r in results:
        print(f"  {r}")
    for e in errors:
        print(f"  {e}", file=sys.stderr)

    if errors and not results:
        config.record_run(f"Found {len(sale_items)} items but delivery failed: {errors[0]}")
        print("\nFound sales but couldn't deliver them. Run: python3 doctor.py",
              file=sys.stderr)
        sys.exit(1)

    config.record_run(f"Checked {len(asins)} products. Sent {len(sale_items)} items. "
                      + "; ".join(results))


if __name__ == "__main__":
    main()
