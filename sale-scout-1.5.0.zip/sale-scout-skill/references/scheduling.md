# Running Sale Scout automatically every morning

You can have Sale Scout run by itself so your email is waiting when you start
work. Ask Claude: *"run Sale Scout every morning at 8"* and it sets this up for
you — you don't need to do any of the steps below yourself.

## The one thing to understand first

**It only runs when your computer is on and awake.**

Sale Scout lives on your machine, not on a server somewhere. If your laptop is
closed or asleep at 8am, nothing happens — and you won't get an email telling you
nothing happened.

Two honest options:

- **Scheduled** — good if you work at a desktop, or leave your laptop open and
  plugged in overnight.
- **Manual** — just ask Claude to run a scan when you sit down to plan content.
  Takes a few minutes and gives you exactly the same results. For a lot of
  creators this is genuinely the better fit.

Neither is more "real" than the other. Pick the one that matches how you work.

---

## macOS

### ⚠️ Where the skill folder lives matters

macOS blocks scheduled jobs from reading **Documents**, **Desktop**, and
**Downloads**. If Sale Scout lives in one of those folders, the daily run fails
every single time with `Operation not permitted` — and because it fails before it
can send anything, **you get no email telling you it failed.** It just silently
never runs.

Two ways around it, in order of preference:

**1. Keep the skill somewhere unprotected.** A folder directly in your home
directory — `~/sale-scout` — works with no extra permissions. This is what Claude
sets up by default.

**2. Or grant Full Disk Access to cron.** System Settings → Privacy & Security →
Full Disk Access → **+** → press `Cmd+Shift+G`, type `/usr/sbin/cron`, add it.
Needed only if you insist on keeping the folder in Documents.

If you set up a daily run and nothing arrives the next morning, this is the first
thing to check.

---

Ask Claude to set this up — it handles the whole thing.

Claude installs a **catch-up scheduler** (launchd), not a plain timer. The
difference matters: a plain timer loses the run entirely if your Mac was asleep
at 8am, while this one runs it the moment your Mac next wakes up. So a late
email beats no email.

It also can't send twice. If you wake your Mac several times in a day, it
notices it already ran and skips.

To check it's there, ask Claude: *"is Sale Scout scheduled?"*
To stop it, ask Claude: *"stop running Sale Scout automatically."*

### If your Mac sleeps overnight

You can have it wake itself: **System Settings → Battery / Energy Saver →
Schedule**, and set a wake time a few minutes before your run. On laptops this
is only reliable when plugged in with the lid open.

Otherwise the catch-up behaviour covers you — you'll get the email when you open
your laptop rather than at 8am sharp.

---

## Windows

Use Task Scheduler:

1. Press Start, search **Task Scheduler**, open it
2. Click **Create Basic Task** on the right
3. Name it `Sale Scout`, click Next
4. Choose **Daily**, click Next
5. Set the time to 8:00 AM, click Next
6. Choose **Start a program**, click Next
7. **Program/script:** `python`
8. **Add arguments:** `run.py --quiet`
9. **Start in:** the full path to the skill's `scripts` folder
10. Click Next, then Finish

Then find the task in the list, right-click → **Properties** → **Conditions**, and
tick **Wake the computer to run this task** if you want it to run while asleep.

---

## Checking that it worked

Scheduled runs write to `~/.sale-scout/log.txt`. Ask Claude to read it — it'll
tell you whether the last run found sales, found nothing, or hit a problem.

If the log is empty the day after setting this up, the schedule didn't fire. The
usual cause is the computer being asleep. Ask Claude to check.
