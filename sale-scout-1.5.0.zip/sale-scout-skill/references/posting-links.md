# Getting paid for the links you post

*A tip from Stefanie Becker (Merit House) and Kelly Stumpe (The Car Mom)*

Sale Scout gives you a link for every product it finds. This is worth two
minutes of your time, because most creators are losing sales to something they
can't see.

---

## The short version

**Your links always track your commission.** Every link in your email has your
affiliate ID built in. Paste it anywhere — a story, a caption, a newsletter, a
text to your sister — and if someone buys, you get paid.

**On a phone, they usually open the Amazon app on their own.** Tap one from a
text message or your notes and the app opens straight to the product. Your
phone does that automatically for Amazon links.

**Instagram and TikTok are the exception, and that's where your audience is.**
Those apps open links in their own little browser instead of handing them to
Amazon. Your follower ends up on the Amazon *website*, inside Instagram, often
not signed in.

---

## Why that costs you money

Someone tapping your story link in Instagram's browser has to sign in to Amazon
again before they can buy. Some of them will. Plenty won't — they'll mean to
come back and never do.

When the Amazon app opens instead, they're already signed in. Their payment
details are saved. Buying is two taps.

Same product, same price, same commission rate. Completely different number of
people who actually complete the purchase.

---

## What to do about it

**For a story or a bio link, grab a short link first.**

On a computer, use **SiteStripe** — the bar across the top of any Amazon page
when you're logged into Associates. Choose the short link option and you'll get
something like `link.amazon/B0iPRDyer`.

On your phone, use **Get Link** in the Amazon app.

Those short links force the Amazon app open, even from inside Instagram. It's a
different kind of link, not a shortened version of the one you have — Amazon
creates it on their end, which is why Sale Scout can't make one for you.

**For everything else, paste the link from your email as-is.** Newsletters,
blog posts, YouTube descriptions, DMs — your email link is perfect. It tracks,
and it opens the app wherever the phone allows it.

---

## How we'd actually work it

Sale Scout tells you the 20 things that are on sale. You're not posting 20
things — you're posting two or three.

So: read the email, pick the two you genuinely want to talk about, and grab
short links for just those. That's a couple of minutes, not an afternoon.

The hard part was never making the link. It was knowing which of your 300
products quietly dropped 40% overnight. That's the part you no longer have to
do.

---

## One more thing worth saying

Affiliate links work best when they're a service rather than a sales pitch.
People follow you because they trust what you recommend. A link to something
genuinely good, at a genuinely good price, on the day the price is good, is
useful to them — and that's what earns the commission.

Sale Scout exists to find those days. What you do with them is the part only
you can do.
