# Setting up your email

Sale Scout sends your daily list from your own Gmail, so it arrives from an
address you control.

Google won't let an app use your normal password. Instead you create a special
16-letter code just for Sale Scout, called an **App Password**. It only works
for this, and you can cancel it any time.

It takes about three minutes.

---

## Step 1 — Turn on 2-Step Verification

You can only make an App Password if this is on. You probably already have it.

1. Go to **myaccount.google.com/security**
2. Look for **2-Step Verification**
3. If it says "Off", click it and follow the steps (Google will text you a code)

---

## Step 2 — Make the App Password

1. Go to **myaccount.google.com/apppasswords**
2. In the box, type: `Sale Scout`
3. Click **Create**

Google shows you 16 letters in four groups, like:

> **abcd efgh ijkl mnop**

**Copy it now.** Google won't show it again — though you can always make a new
one if you lose it.

---

## Step 3 — Give it to Claude

Paste those letters into your chat with Claude. Spaces are fine.

Claude will also ask:

- **Which Gmail should send it** — usually your own
- **Where the email should arrive** — usually the same address

---

## If the App Passwords page won't open

This is the most common snag, and there are only two causes:

**2-Step Verification isn't fully on.** Go back to Step 1 and finish it. The App
Passwords page simply doesn't exist until that's done.

**Your email is through work or school.** If your address is a company one
(Google Workspace), your administrator may have switched this feature off. You
won't be able to turn it on yourself. The quickest fix is to use a personal
Gmail address instead — the emails will still arrive wherever you want them.

---

## Other things people hit

**"Gmail rejected the login"**
Almost always your normal Gmail password got pasted instead of the App Password.
App Passwords are 16 letters, no numbers or symbols.

**The email went to spam**
Open it, click **Not spam**. Gmail learns after one or two.

**I changed my Google password and it stopped working**
That cancels all App Passwords. Just make a new one and give it to Claude — it
takes two minutes.
