# Setting up Slack delivery

Optional. Use this if you'd rather get your daily sales in Slack than email, or
want both — for example, a channel your team can see.

## Step 1 — Create a Slack app

1. Go to **api.slack.com/apps** and click **Create New App**
2. Choose **From scratch**
3. Name it `Sale Scout` and pick your workspace

## Step 2 — Give it permission to post

1. In the left sidebar, click **OAuth & Permissions**
2. Scroll to **Scopes → Bot Token Scopes**
3. Click **Add an OAuth Scope** and add:
   - `chat:write` — post messages
   - `chat:write.public` — post to public channels without being invited first

## Step 3 — Install it

1. Scroll up to **OAuth Tokens for Your Workspace**
2. Click **Install to Workspace** and approve
3. Copy the **Bot User OAuth Token** — it starts with `xoxb-`

## Step 4 — Pick a channel

Decide where the digest should post, e.g. `#sales` or `#content-planning`.

If it's a **private** channel, you must invite the bot. In that channel, type:

```
/invite @Sale Scout
```

Public channels work without this if you added `chat:write.public`.

## Step 5 — Give it to Claude

Paste the `xoxb-` token and the channel name into your chat.

## Common problems

**`not_in_channel`**
The bot isn't in that channel. Invite it with `/invite @Sale Scout`.

**`channel_not_found`**
Check the spelling. Leave off the `#` — just `sales`, not `#sales`. Private
channels the bot hasn't been invited to also report this.

**`invalid_auth`**
Wrong token. It must be the **Bot User OAuth Token** starting `xoxb-`, not the
App-Level Token (`xapp-`) or the Client Secret.

**Only some products appear**
Slack limits how much fits in one message, so very long digests are trimmed to
the 40 biggest discounts. Email has no such limit.
