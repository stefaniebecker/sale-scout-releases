"""
Sale Scout — "who's on sale" across major retailers.

Creators want to know when Anthropologie or Athleta is running a sitewide sale,
not only what's discounted on Amazon. These are informational only — no
affiliate links, just a heads-up so they know to go make content.

Uses a plain HTTP fetch rather than a browser. Counterintuitively this works far
better: several of these sites block headless browsers outright (Anthropologie
returns an empty page to Playwright) but serve their promo banner happily in the
raw HTML. It's also ~10x faster and gentler on the sites.

Returning nothing for a retailer is fine and expected. Some block us, some have
no sale on. A missed sale is a non-event; a *wrong* one erodes trust, so the
filtering below is deliberately strict.
"""

import gzip
import html as htmllib
import re
import sys
import urllib.request

RETAILERS = [
    ("Target",              "https://www.target.com"),
    ("Anthropologie",       "https://www.anthropologie.com"),
    ("Athleta",             "https://athleta.gap.com"),
    ("Lululemon",           "https://shop.lululemon.com"),
    ("Nordstrom",           "https://www.nordstrom.com"),
    ("Old Navy",            "https://oldnavy.gap.com"),
    ("Aritzia",             "https://www.aritzia.com"),
    ("Abercrombie & Fitch", "https://www.abercrombie.com"),
    ("Free People",         "https://www.freepeople.com"),
    ("Madewell",            "https://www.madewell.com"),
    ("Zara",                "https://www.zara.com/us/"),
    ("H&M",                 "https://www2.hm.com/en_us/index.html"),
    ("Gap",                 "https://www.gap.com"),
    ("Banana Republic",     "https://bananarepublic.gap.com"),
    ("Spanx",               "https://spanx.com"),
    ("LOFT",                "https://www.loft.com"),
    ("J.Crew",              "https://www.jcrew.com"),
    ("Quince",              "https://www.quince.com"),
]

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")

# A real promotion mentions a discount.
OFFER_RE = re.compile(
    r"[^<>\n\"]{0,70}?"
    r"(?:\b\d{1,2}%\s*off\b|\bup to\s+\d{1,2}%\b|\bextra\s+\d{1,2}%\s*off\b|\$\d{1,3}\s*off\b)"
    r"[^<>\n\"]{0,70}", re.IGNORECASE)

# Things that mention a discount but aren't a sale the creator can post about.
NOISE_RE = re.compile(
    r"\b("
    r"sign\s*up|signup|join\s+the\s+list|subscribe|newsletter|email\s+list|"
    r"text\s+club|sms|"
    r"credit\s*card|cardmember|card\s*holder|when\s+you\s+open|new\s+card|"
    r"card\s*perk|with\s+your\s+card|rewards?\s+member|loyalty|"
    r"\d[\d,]*\s*points?|redeem|"
    r"your\s+first\s+(?:order|purchase)|first\s+(?:order|purchase)|"
    r"next\s+(?:order|purchase)|"
    r"welcome\s+offer|refer\s+a\s+friend|student\s+discount|military"
    r")\b", re.IGNORECASE)

# Rejected outright. "Up to 50% off" and "extra 70% off sale styles" sit on these
# sites permanently — they describe a clearance rack, not news a creator can post.
# A real sale states a firm percentage: "30% off fall looks".
VAGUE_RE = re.compile(
    r"up\s+to\s+\d{1,2}\s*%"                    # ceiling, not an offer
    r"|\bextra\s+\d{1,2}\s*%"                   # "extra 70% off" = clearance mechanic
    r"|\badditional\s+\d{1,2}\s*%"
    r"|\d{1,2}\s*%\s*off\s+(?:sale|clearance|markdown|final)"
    r"|\bsale\s+styles\b|\bclearance\b|\bfinal\s+sale\b|\bmarkdowns\b"
    r"|\bselect\s+(?:styles|items|colors|sizes)\b"   # "40% off select styles" = vague
    r"|\bstarting\s+at\b|\bfrom\s+\$|\bas\s+low\s+as\b"
    r"|\bbogo\b|\bbuy\s+one\b|\bb1g1\b"          # different mechanic, usually permanent
    r"|\bwhen\s+you\s+spend\b"                   # spend-threshold gimmick
    # Trade-in events and upcoming sales are deliberately NOT filtered: a creator
    # wants advance notice of Target's car seat trade-in, and "starts Saturday" is
    # useful precisely because it's early.
    r"|\d{1,2}\s*%?\s*[-–—]\s*\d{1,2}\s*%",      # "40–60% off" — a range, same problem
    re.IGNORECASE)

# Phrases that mark a genuine storewide promotion — used to rank, not require.
STRONG_RE = re.compile(
    r"\b(limited\s+time|sitewide|site\s*wide|sale\s+styles|everything|"
    r"your\s+purchase|ends\s+(?:today|soon|sunday|monday)|all\s+\w+\s+styles|"
    r"markdowns|clearance|friends?\s*&?\s*family)\b", re.IGNORECASE)

# Leftover markup fragments that survive a crude text extraction.
JUNK_RE = re.compile(r"(https?://|[{}\[\]\\]|&[a-z]+;?q=|fetchPriority|colorScheme|"
                     r"alternateText|promoOfferMessage|\bnull\b|\bu003)", re.IGNORECASE)

# Image alt-text often describes the photo rather than stating the offer
# ("Men's sale ad: '50% off deals', with two models in denim"). Accurate, but
# not something to put in a creator's email.
ALT_DESC_RE = re.compile(r"(\bad:|\bwith (?:two|three|a) model|\bmodels?\b|"
                         r"\bwearing\b|\bposing\b|\bphoto\b|\bimage of\b|[""''])",
                         re.IGNORECASE)


def _fetch(url, timeout=20):
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
        if r.headers.get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        return raw.decode("utf-8", "ignore")


def _clean(text):
    text = htmllib.unescape(text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    text = text.strip(" *–—-|,.")
    return text.strip()


def _best_offer(page_html):
    """Return the most credible promo line on the page, or None."""
    candidates = []
    for raw in OFFER_RE.findall(page_html):
        text = _clean(raw)
        if not text or len(text) < 8 or len(text) > 120:
            continue
        if (JUNK_RE.search(text) or NOISE_RE.search(text)
                or ALT_DESC_RE.search(text) or VAGUE_RE.search(text)):
            continue
        # Must state a firm percentage off — "30% off", not "up to 30%".
        if not re.search(r"\b\d{1,2}%\s*off\b", text, re.I):
            continue
        candidates.append(text)

    if not candidates:
        return None

    # Rank: storewide-sounding first, then bigger discounts.
    def score(t):
        pct = max([int(m) for m in re.findall(r"(\d{1,2})%", t)] or [0])
        brevity = -len(t)          # shorter reads better in an email
        return (1 if STRONG_RE.search(t) else 0, pct, brevity)

    candidates = list(dict.fromkeys(candidates))
    candidates.sort(key=score, reverse=True)
    return candidates[0]


def check_retailers(retailers=None, verbose=True):
    """Return [(brand, offer_text)] for real sales only.

    Deliberately strict. Most days this returns little or nothing, which is
    accurate — genuine sitewide sales are rare outside holidays. Reporting a
    permanent clearance rack as news would train creators to ignore the section.
    """
    retailers = retailers or RETAILERS
    found = []

    for name, url in retailers:
        try:
            offer = _best_offer(_fetch(url))
        except Exception as e:
            if verbose:
                print(f"  {name:22s} (unavailable: {str(e)[:40]})", file=sys.stderr)
            continue

        if offer:
            found.append((name, offer))
            if verbose:
                print(f"  {name:22s} {offer}")
        elif verbose:
            print(f"  {name:22s} —")

    return found


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    args = ap.parse_args()

    targets = RETAILERS
    if args.only:
        wanted = [w.lower() for w in args.only]
        targets = [(n, u) for n, u in RETAILERS if any(w in n.lower() for w in wanted)]

    print(f"Checking {len(targets)} retailers...\n")
    results = check_retailers(targets)
    print(f"\n{len(results)} of {len(targets)} running a real sale right now.")
