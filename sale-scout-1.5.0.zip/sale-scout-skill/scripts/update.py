"""
Sale Scout — self-update.

    python3 update.py --check     see whether a newer version exists
    python3 update.py             download and install it

Settings live in ~/.sale-scout/config.json, outside the skill folder, so an
update never touches credentials, the mute list, or the threshold. The creator's
own logo in assets/ is preserved too.
"""

import io
import json
import os
import shutil
import sys
import tempfile
import urllib.request
import zipfile

from version import VERSION, VERSION_URL

SKILL_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Replaced wholesale on update. Anything not listed is left alone, which is how
# a creator's own logo and any local tweaks survive.
REPLACE = ["scripts", "references", "SKILL.md", "README.md"]

# Never overwritten, even inside a replaced folder.
PRESERVE = ["assets/logo.png", "assets/logo.jpg", "assets/logo.jpeg"]


def _parse(v):
    try:
        return tuple(int(p) for p in str(v).strip().split("."))
    except ValueError:
        return (0,)


def check():
    """Return (latest_version, url, notes) or None if already current."""
    try:
        with urllib.request.urlopen(VERSION_URL, timeout=20) as r:
            info = json.loads(r.read().decode())
    except Exception as e:
        print(f"Couldn't check for updates: {str(e)[:120]}", file=sys.stderr)
        return None

    latest = info.get("version", "")
    if _parse(latest) > _parse(VERSION):
        return latest, info.get("url", ""), info.get("notes", "")
    return None


def install(url):
    """Download the release zip and swap in the new files."""
    print("Downloading the update...")
    with urllib.request.urlopen(url, timeout=120) as r:
        data = r.read()

    with tempfile.TemporaryDirectory() as tmp:
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                z.extractall(tmp)
        except zipfile.BadZipFile:
            print("That download wasn't a valid update file. Nothing was changed.",
                  file=sys.stderr)
            return False

        # A zip usually contains one top-level folder; step into it if so.
        entries = [e for e in os.listdir(tmp) if not e.startswith(("_", "."))]
        root = tmp
        if len(entries) == 1 and os.path.isdir(os.path.join(tmp, entries[0])):
            root = os.path.join(tmp, entries[0])

        if not os.path.exists(os.path.join(root, "SKILL.md")):
            print("That update doesn't look like Sale Scout. Nothing was changed.",
                  file=sys.stderr)
            return False

        # Keep the creator's own files safe while we swap folders.
        stash = {}
        for rel in PRESERVE:
            src = os.path.join(SKILL_DIR, rel)
            if os.path.exists(src):
                stash[rel] = open(src, "rb").read()

        for item in REPLACE:
            new = os.path.join(root, item)
            old = os.path.join(SKILL_DIR, item)
            if not os.path.exists(new):
                continue
            if os.path.isdir(new):
                shutil.rmtree(old, ignore_errors=True)
                shutil.copytree(new, old)
            else:
                shutil.copy2(new, old)

        for rel, blob in stash.items():
            dest = os.path.join(SKILL_DIR, rel)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "wb") as f:
                f.write(blob)

    return True


def main():
    check_only = "--check" in sys.argv
    print(f"Installed version: {VERSION}")

    found = check()
    if not found:
        print("You're on the latest version.")
        return

    latest, url, notes = found
    print(f"Version {latest} is available." + (f"\n  {notes}" if notes else ""))

    if check_only:
        print("\nRun without --check to install it.")
        return

    if not url:
        print("No download link was published for that version.", file=sys.stderr)
        sys.exit(1)

    if install(url):
        print(f"\nUpdated to {latest}. Your settings and logo were kept.")
        print("Run: python3 doctor.py  to confirm everything still works.")
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
