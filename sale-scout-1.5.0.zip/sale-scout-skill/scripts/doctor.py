"""
Sale Scout — self-check.

    python3 doctor.py

Tests every part of the chain separately and says exactly which link is broken
and how to fix it. Run this whenever something misbehaves, before changing
anything. Checks stop being useful the moment they're vague, so each failure
here names a cause and a next step.

Never prints secrets — only their length and fixed prefix, which is enough to
spot a truncated paste.
"""

import os
import sys

import config

PASS = "  PASS"
FAIL = "  FAIL"
WARN = "  WARN"
SKIP = "  SKIP"

failures = []


def report(status, label, detail=""):
    print(f"{status}  {label}")
    if detail:
        for line in detail.strip().split("\n"):
            print(f"        {line}")
    if status == FAIL:
        failures.append(label)


def check_version():
    from version import VERSION
    report(PASS, "Sale Scout version", VERSION)
    try:
        import update
        found = update.check()
        if found:
            report(WARN, "Update available",
                   f"Version {found[0]} is out." + (f" {found[2]}" if found[2] else "")
                   + "\nAsk Claude to update Sale Scout.")
    except Exception:
        pass   # never let an update check block the diagnostics


def check_python():
    v = sys.version_info
    if v < (3, 9):
        report(FAIL, "Python version",
               f"Found {v.major}.{v.minor}. Sale Scout needs Python 3.9 or newer.")
    else:
        report(PASS, "Python version", f"{v.major}.{v.minor}.{v.micro}")


def check_packages():
    missing = []
    # Pinned to the tested versions. The Amazon SDK has changed its interface
    # between releases, so an unpinned install can break a fresh setup.
    for mod, pkg in [("playwright", '"playwright==1.44.0"'),
                     ("creatorsapi_python_sdk", '"amazon-creatorsapi-python-sdk==1.0.0"')]:
        try:
            __import__(mod)
        except ImportError:
            missing.append(pkg)
    if missing:
        report(FAIL, "Required packages",
               "Missing: " + ", ".join(missing) +
               "\nInstall with: pip3 install " + " ".join(missing))
    else:
        report(PASS, "Required packages")


def check_browser():
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        report(SKIP, "Browser (Playwright Chromium)", "Playwright isn't installed yet.")
        return
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            browser.close()
        report(PASS, "Browser (Playwright Chromium)")
    except Exception as e:
        report(FAIL, "Browser (Playwright Chromium)",
               f"{str(e)[:160]}\nInstall it with: python3 -m playwright install chromium")


def check_scope_patch():
    """The SDK ships a wrong OAuth scope; amazon.py overrides it on import."""
    try:
        import amazon  # noqa: F401  (import applies the patch)
        from creatorsapi_python_sdk.auth.oauth2_config import OAuth2Config
        if OAuth2Config.SCOPE == "creatorsapi::default":
            report(PASS, "Amazon SDK scope fix")
        else:
            report(FAIL, "Amazon SDK scope fix",
                   f"Scope is '{OAuth2Config.SCOPE}', expected 'creatorsapi::default'. "
                   "Amazon will reject every request with a 400 error.")
    except Exception as e:
        report(WARN, "Amazon SDK scope fix", f"Couldn't verify: {str(e)[:120]}")


def check_config():
    cfg = config.load()
    if not os.path.exists(config.CONFIG_PATH):
        report(FAIL, "Settings file",
               f"No settings yet at {config.CONFIG_PATH}.\n"
               "Ask Claude to set up Sale Scout.")
        return None

    missing = config.missing_fields(cfg)
    if missing:
        report(FAIL, "Settings complete", "Still needed: " + ", ".join(missing))
    else:
        report(PASS, "Settings complete", f"Saved at {config.CONFIG_PATH}")

    # Shape check — a truncated credential is the single most common setup mistake
    cid = cfg.get("amazon_credential_id", "")
    sec = cfg.get("amazon_client_secret", "")
    if cid and not cid.startswith("amzn1.application-oa2-"):
        report(WARN, "Credential ID format",
               f"Starts '{cid[:22]}', expected 'amzn1.application-oa2-'.")
    if sec and not sec.startswith("amzn1.oa2-cs."):
        report(WARN, "Client Secret format",
               f"Starts '{sec[:14]}', expected 'amzn1.oa2-cs.v1.'. "
               "Check you copied the Secret, not the Credential ID.")
    elif sec and len(sec) < 60:
        report(WARN, "Client Secret length",
               f"Only {len(sec)} characters — expected around 80. "
               "It may have been cut off when copied.")

    days = config.days_since_last_run(cfg)
    if days is None:
        report(WARN, "Last run", "Sale Scout has never completed a run yet.")
    elif days >= 2:
        report(FAIL, "Last run",
               f"{days} days ago. A scheduled run only happens when this computer "
               f"is awake at the scheduled time — a closed laptop skips it silently.\n"
               f"Last outcome: {cfg.get('last_run_summary', 'unknown')}")
    else:
        report(PASS, "Last run",
               f"{cfg.get('last_run_at', '')} — {cfg.get('last_run_summary', '')}")

    mode = oct(os.stat(config.CONFIG_PATH).st_mode)[-3:]
    if mode != "600":
        report(WARN, "Settings file permissions",
               f"File is {mode}; should be 600 (only you can read it).")

    return cfg


def check_amazon(cfg):
    """One real API call — the only way to know the credentials actually work."""
    if not cfg or not cfg.get("amazon_credential_id") or not cfg.get("amazon_client_secret"):
        report(SKIP, "Amazon API connection", "Credentials not set yet.")
        return
    try:
        from amazon import build_api, get_sale_items
        api = build_api(cfg["amazon_credential_id"], cfg["amazon_client_secret"])
        stats = {}
        get_sale_items(api, ["B000R5PKD0"], 1,
                       partner_tag=cfg.get("affiliate_tag", ""),
                       stats=stats, verbose=False)
        if stats.get("batches_ok"):
            report(PASS, "Amazon API connection", "Credentials accepted.")
        else:
            err = str(stats.get("last_error", ""))
            hint = ""
            if "invalid_client" in err or "401" in err:
                hint = ("\nAmazon doesn't recognise this ID/Secret pair. Re-copy both "
                        "from the Creators API section of Amazon Associates.")
            elif "400" in err:
                hint = ("\nUsually the OAuth scope — check the 'Amazon SDK scope fix' "
                        "line above.")
            report(FAIL, "Amazon API connection", f"{err[:200]}{hint}")
    except Exception as e:
        report(FAIL, "Amazon API connection", str(e)[:200])


def check_storefront(cfg):
    if not cfg or not cfg.get("storefront_handle"):
        report(SKIP, "Storefront", "Handle not set yet.")
        return
    report(SKIP, "Storefront scrape",
           f"Not run here — it takes several minutes. To test it:\n"
           f"python3 run.py --dry-run")


def check_email(cfg):
    """Log in to Gmail without sending anything."""
    if not cfg or not cfg.get("deliver_to_email"):
        report(SKIP, "Email delivery", "Email delivery is off.")
        return
    addr = cfg.get("gmail_address", "")
    pw   = cfg.get("gmail_app_password", "")
    if not addr or not pw:
        report(FAIL, "Email delivery", "Gmail address or app password missing.")
        return

    cleaned = pw.replace(" ", "")
    if len(cleaned) != 16:
        report(WARN, "Gmail app password length",
               f"{len(cleaned)} characters after removing spaces; Google's app "
               "passwords are 16. This may be a regular password, which won't work.")

    import smtplib
    try:
        with smtplib.SMTP("smtp.gmail.com", 587, timeout=20) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.login(addr, pw)
        report(PASS, "Email delivery", f"Gmail accepted the login for {addr}")
    except smtplib.SMTPAuthenticationError:
        report(FAIL, "Email delivery",
               "Gmail rejected the login.\n"
               "Use a 16-character App Password from myaccount.google.com/apppasswords\n"
               "(requires 2-Step Verification), not your normal Gmail password.")
    except Exception as e:
        report(FAIL, "Email delivery", f"Couldn't reach Gmail: {str(e)[:160]}")


def check_slack(cfg):
    if not cfg or not cfg.get("deliver_to_slack"):
        report(SKIP, "Slack delivery", "Slack delivery is off.")
        return
    import json
    import urllib.request
    token = cfg.get("slack_bot_token", "")
    if not token:
        report(FAIL, "Slack delivery", "Bot token missing.")
        return
    try:
        req = urllib.request.Request(
            "https://slack.com/api/auth.test",
            headers={"Authorization": f"Bearer {token}"}, method="POST")
        with urllib.request.urlopen(req, timeout=20) as resp:
            body = json.loads(resp.read().decode())
        if body.get("ok"):
            report(PASS, "Slack delivery", f"Connected to {body.get('team', 'Slack')}")
        else:
            report(FAIL, "Slack delivery", f"Slack said: {body.get('error')}")
    except Exception as e:
        report(FAIL, "Slack delivery", f"Couldn't reach Slack: {str(e)[:160]}")


def check_logo(cfg):
    from notify import _logo_bytes
    data, subtype = _logo_bytes(cfg)
    if data:
        kb = len(data) / 1024
        detail = f"{subtype.upper()}, {kb:.0f} KB"
        if kb > 500:
            detail += " — over 500 KB may be slow to load in email."
        report(PASS, "Logo", detail)
    else:
        report(WARN, "Logo",
               "No logo found, so emails use your name as text instead.\n"
               "Add one by saving a PNG to the skill's assets/logo.png")


def main():
    print("\nSale Scout — checking your setup\n" + "─" * 46)
    check_version()
    check_python()
    check_packages()
    check_browser()
    check_scope_patch()
    print()
    cfg = check_config()
    check_logo(cfg)
    print()
    check_amazon(cfg)
    check_storefront(cfg)
    check_email(cfg)
    check_slack(cfg)

    print("─" * 46)
    if failures:
        print(f"{len(failures)} problem(s) to fix: " + ", ".join(failures))
        print("Ask Claude to help with whichever one is listed first.\n")
        sys.exit(1)
    print("Everything checks out. Run it with: python3 run.py\n")


if __name__ == "__main__":
    main()
