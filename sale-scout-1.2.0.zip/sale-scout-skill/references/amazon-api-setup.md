# Getting your Amazon access

This is the one slow step, and the only one you can't rush — **Amazon reviews it
by hand and it can take a few days**.

Do it first, before anything else. Then Claude will set up everything else while
you wait.

---

## What this actually is

You already have an **Amazon Associates** account — that's how you earn
commission on your storefront.

Sale Scout needs something separate: permission to *ask Amazon about prices*.
Amazon calls this the **Product Advertising API**. It's free. You just have to
apply and be approved.

Without it, Sale Scout can see what's in your storefront but can't tell what
anything costs.

---

## Step 1 — Apply

1. Sign in at **associates.amazon.com**
2. At the top, click **Tools**
3. Click **Product Advertising API**
4. Click **Join** (or **Request access**)

Then wait. Amazon usually replies within a few days.

**If they say no:** Amazon normally wants to see that your Associates account
has made a few sales first. That's the usual reason for a decline, and it isn't
personal — make some sales through your storefront and apply again.

---

## Step 2 — Get your two codes

Once Amazon approves you:

1. Go back to **Tools → Product Advertising API**
2. Click **Manage your credentials**
3. Create a new set

Amazon gives you two things:

| What Amazon calls it | What it looks like |
|---|---|
| **Credential ID** | A long code starting `amzn1.application-oa2-client...` |
| **Client Secret** | A long code starting `amzn1.oa2-cs...` |

---

## ⚠️ Copy the second code before you close that page

Amazon shows the **Client Secret** one time only. Once you leave that page it's
gone forever and cannot be recovered.

Copy both codes somewhere safe first — a note to yourself, an email to yourself,
anywhere.

If you've already closed it and don't have the Secret, don't worry: delete that
set and create a new one. Just copy both halves this time.

---

## Step 3 — Give them to Claude

Paste both codes into your chat. Claude saves them on your own computer. They
are never sent anywhere else, and Merit House never sees them.

---

## If something doesn't work

**"Invalid client" or an error mentioning 401**
Usually the second code got cut off when copying. It should be quite long —
around 80 characters. If yours looks short, copy it again.

**A 400 error with a long jumble of letters**
That's a known bug in Amazon's own software, and Sale Scout already works around
it. Ask Claude to run the check-up and it'll confirm.

**"I have keys already but they don't work"**
Make sure they came from **Product Advertising API**. Keys from other Amazon
services (ones starting `AKIA`) are a different thing and won't work here.
