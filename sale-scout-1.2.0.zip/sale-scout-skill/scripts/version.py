"""Sale Scout version and update settings."""

VERSION = "1.2.0"

# Where update.py looks for a newer release. Publish a zip of the skill folder
# here and every installed copy can pull it with "update Sale Scout".
# The JSON at VERSION_URL should look like:
#   {"version": "1.1.0", "url": "https://.../sale-scout-1.1.0.zip",
#    "notes": "Adds retailer sale checks"}
VERSION_URL = ("https://raw.githubusercontent.com/stefaniebecker/"
               "sale-scout-releases/main/latest.json")
