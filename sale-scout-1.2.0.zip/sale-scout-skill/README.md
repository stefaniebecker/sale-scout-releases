# Sale Scout

**Find out what's on sale in your Amazon storefront — every morning, before you post.**

Created by **Kelly Stumpe** of The Car Mom and **Stefanie Becker** of Merit House
— built for the way creators actually work, because one of us does this every day.

---

## What it does

Every morning, Sale Scout looks at every product in your Amazon storefront,
finds the ones that have gone on sale, and emails you a list with links you can
post straight away.

No more checking prices by hand. No more wondering what to post.

It also tells you when big stores like Anthropologie or Target are running a
real sale, so you know when something's worth covering.

---

## What you need before you start

Three things. Please read these — the first one takes the longest.

**1. Amazon API access.** This is a free application inside your Amazon
Associates account, but **Amazon reviews it by hand and it can take a few
days**. Nothing can check prices until they approve you. Claude will help you
apply on day one so the clock starts right away.

**2. The Claude Code app** on a Mac or Windows computer — the version that can
work with files, not the website. Get it at claude.ai/download.

**3. A computer that's on in the morning.** Sale Scout runs on your own machine,
so it can't check prices while your laptop is closed. If your computer is
usually asleep, you can just ask Claude to run it whenever you sit down instead
— same result.

---

## How to install it

**You do not need to type any commands. Ever.** If anything ever looks like
computer code, just say to Claude: *"can you do that for me?"*

**Step 1.** Download the file. It'll go to your Downloads folder.

**Step 2.** Open the **Claude Code** app.

**Step 3.** Type this to Claude, exactly:

> Please install the Sale Scout skill. The file is in my Downloads folder.

Claude will unzip it and put it where it belongs.

**Step 4.** When it's done, say:

> Set up Sale Scout

That's it. Claude takes it from there.

<details>
<summary>If you'd rather do it by hand</summary>

Unzip the file, then move the `sale-scout-skill` folder into:

- **Mac:** `~/.claude/skills` — in Finder press **Cmd + Shift + G**, paste that, press Enter
- **Windows:** `C:\Users\YourName\.claude\skills`

If that folder doesn't exist, make it.
</details>

---

## What happens next

So you know what to expect, and nothing feels broken:

**First, Claude installs a few things it needs.** One is a browser component
that's a big download. **This can take several minutes and looks like nothing is
happening.** That's normal — let it finish.

You may see a pop-up from your Mac asking to install "command line developer
tools." Click **Install** and wait.

**Then Claude helps you apply for Amazon access.** This is the slow part, so
it's done first. Once you've applied, you wait for Amazon — usually a few days.

**While you wait, Claude sets up everything else** — your storefront, your logo,
your colours, and where your emails should go.

**When Amazon approves you**, come back, paste in the two codes they give you,
and you're running.

---

## Once it's set up

Just talk to Claude normally:

- *"What's on sale today?"*
- *"Only show me things 30% off or more"*
- *"Stop showing me that cooler"*
- *"Send me a test email so I can see what it looks like"*
- *"Run Sale Scout every morning at 8"*
- *"Sale Scout isn't working"*
- *"Update Sale Scout"*

---

## If something goes wrong

Say to Claude: **"Run the Sale Scout check-up."**

It tests every part separately and tells you exactly which piece needs fixing,
in plain language. Start there before changing anything.

---

## Your information stays yours

Your Amazon and email details are saved on your own computer and nowhere else.
Merit House never receives them and can't see your storefront, your sales, or
your inbox.

---

## More detail, if you want it

| | |
|---|---|
| Getting Amazon access | [amazon-api-setup.md](references/amazon-api-setup.md) |
| Setting up email | [gmail-setup.md](references/gmail-setup.md) |
| Sending to Slack instead | [slack-setup.md](references/slack-setup.md) |
| Running it automatically | [scheduling.md](references/scheduling.md) |
| Fixing problems | [troubleshooting.md](references/troubleshooting.md) |

---

Sale Scout was created by **Kelly Stumpe** (The Car Mom) and **Stefanie Becker**
(Merit House).

Merit House is the team behind your favorite content creator.
Email marketing · SEO & AEO · AI support ·
[themerithouse.com](https://themerithouse.com)
