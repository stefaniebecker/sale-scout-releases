# Setting up your email

Sale Scout sends your daily list from your own email, so it arrives from an
address you control.

**Gmail is what we recommend.** It's the quickest to set up and the one we've
tested most. If you don't have one, a free Gmail made just for this works
perfectly. Outlook, iCloud and Yahoo work too — skip to the bottom for those.

Your email provider won't let an app use your normal password. Instead you
create a special code just for Sale Scout, called an **app password**. It only
works for this, and you can cancel it any time.

It takes about three minutes.

---

## Step 1 — Turn on 2-Step Verification

You can only make an App Password if this is on. You probably already have it.

1. Go to **myaccount.google.com/security**
2. Look for **2-Step Verification**
3. If it says "Off", click it and follow the steps (Google will text you a code)

---

## Step 2 — Make the App Password

1. Go to **myaccount.google.com/apppasswords**
2. In the box, type: `Sale Scout`
3. Click **Create**

Google shows you 16 letters in four groups, like:

> **abcd efgh ijkl mnop**

**Copy it now.** Google won't show it again — though you can always make a new
one if you lose it.

---

## Step 3 — Give it to Claude

Paste those letters into your chat with Claude. Spaces are fine.

Claude will also ask:

- **Which Gmail should send it** — usually your own
- **Where the email should arrive** — usually the same address

---

## If the App Passwords page won't open

This is the most common snag, and there are only two causes:

**2-Step Verification isn't fully on.** Go back to Step 1 and finish it. The App
Passwords page simply doesn't exist until that's done.

**Your email is through work or school.** If your address is a company one
(Google Workspace), your administrator may have switched this feature off. You
won't be able to turn it on yourself. The quickest fix is to use a personal
Gmail address instead — the emails will still arrive wherever you want them.

---

## Other things people hit

**"Gmail rejected the login"**
Almost always your normal Gmail password got pasted instead of the App Password.
App Passwords are 16 letters, no numbers or symbols.

**The email went to spam**
Open it, click **Not spam**. Gmail learns after one or two.

**I changed my Google password and it stopped working**
That cancels all App Passwords. Just make a new one and give it to Claude — it
takes two minutes.

---

## If you don't use Gmail

Same idea everywhere — you make an app password, paste it to Claude, done. Only
the place you get it changes. Sale Scout works out the rest from your address.

**Outlook / Hotmail / Live**
account.microsoft.com → Security → Advanced security options → App passwords

**iCloud**
appleid.apple.com → Sign-In and Security → App-Specific Passwords

**Yahoo**
Account Security → Generate app password

**Your own domain** (like hello@yourbrand.com)
Most run through Google behind the scenes, in which case it works exactly like
Gmail above. If yours doesn't, tell Claude your mail server and it'll save it.

A note worth being straight about: Gmail is the one we've tested most. If you're
on another provider and something won't cooperate, email us rather than fighting
it — and a free Gmail just for Sale Scout is always the quick way through.
