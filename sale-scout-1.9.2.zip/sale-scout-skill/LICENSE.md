# Sale Scout — Licence

Copyright © 2026 Stefanie Becker (Merit House) and Kelly Stumpe (The Car Mom).
All rights reserved.

---

## In plain English

You bought a licence to **use** Sale Scout. You didn't buy the right to sell it,
give it away, or repackage it.

**You can:**

- Use it for your own storefronts, as many as you like
- Change it however you want for your own use
- Keep using it forever, including after support ends

**You can't:**

- Sell it, resell it, or include it in anything you sell
- Give it away, share the files, or post them anywhere
- Repackage it under another name, with or without changes
- Use it as the basis for a competing product
- Remove the credit to Kelly Stumpe and Stefanie Becker from the emails it sends

If someone asks where you got it, please send them to buy their own copy rather
than sending them yours. It's one person's work and a creator's livelihood.

---

## The formal version

This software and its documentation are licensed, not sold.

**Grant.** You are granted a non-exclusive, non-transferable licence to install
and use one copy of Sale Scout for your own business purposes, on computers you
control.

**Restrictions.** You may not distribute, sublicense, rent, lease, sell, resell,
publish, or otherwise make Sale Scout or any derivative of it available to any
third party, whether or not for payment, and whether or not modified. You may
not create a competing or substantially similar product derived from this work.
You may not remove or alter the attribution to the authors contained in the
output this software produces.

**Modification.** You may modify your own copy for your own use. Modified copies
remain subject to every restriction above.

**Ownership.** All rights not expressly granted are reserved by the authors.
Nothing in this licence transfers ownership of the software, its documentation,
or any intellectual property in them.

**Termination.** This licence terminates automatically if you breach it. On
termination you must stop using Sale Scout and delete your copies.

**No warranty.** Sale Scout is provided "as is", without warranty of any kind.
The authors are not liable for any loss arising from its use, including lost
commission, missed sales, or any action taken by Amazon in relation to your
Associates account.

**Third parties.** Sale Scout is independent and is not sponsored, endorsed, or
operated by Amazon or by Anthropic. Your use of Amazon's services remains subject
to Amazon's own terms, including the Amazon Associates Operating Agreement.

---

## Questions

hello@stefaniebeckerdigital.com

If you'd like to use Sale Scout in a way this licence doesn't allow — for an
agency, for clients, or bundled into something of your own — just ask. There's
likely an arrangement that works.
