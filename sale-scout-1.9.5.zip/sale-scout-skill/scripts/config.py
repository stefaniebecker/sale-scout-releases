"""
Sale Scout — configuration.

Settings live in ~/.sale-scout/config.json, deliberately OUTSIDE the skill folder
so updating the skill never overwrites someone's credentials or mute list.
The file is written 0600 (owner read/write only) because it holds secrets.
"""

import json
import os
import stat

CONFIG_DIR  = os.path.expanduser("~/.sale-scout")
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")

DEFAULTS = {
    "storefront_handle": "",
    "affiliate_tag": "",
    "amazon_credential_id": "",
    "amazon_client_secret": "",

    "deliver_to_email": True,
    "alert_email": "",
    "gmail_address": "",
    "gmail_app_password": "",

    "deliver_to_slack": False,
    "slack_bot_token": "",
    "slack_channel": "",

    "threshold_pct": 25,

    # Informational only — no affiliate links. Tells the creator which major
    # retailers are running a sale so they know to go make content.
    "check_retailers": True,
    "excluded_asins": [],
    "excluded_keywords": [],

    "brand_name": "",
    "brand_color": "#3D2030",
    "logo_path": "",          # optional; falls back to assets/logo.png

    # Written by run.py. A scheduled run only fires when the computer is awake, so a
    # silent gap is the most likely failure — this makes the gap visible.
    "last_run_at": "",
    "last_run_summary": "",

    # Set when a daily schedule is installed, so "why is there no email?" can be
    # answered with "it isn't due for another 20 minutes" instead of a hunt.
    "scheduled_hour": None,
    "scheduled_minute": 0,

    # Amazon approval takes days. People start setup, hit that wait, and never
    # come back — so the scheduled run reminds them. See nudge.py.
    "setup_started_at": "",
    "last_nudge_at": "",

    # Credentials are password-like, so they get a yearly rotation nudge.
    # See security.py.
    "credentials_saved_at": "",
    "last_rotation_notice_at": "",

    # Highest product count seen in a healthy scrape. Amazon intermittently
    # serves a degraded storefront page; without a baseline, a collapsed scrape
    # is indistinguishable from "nothing on sale today".
    "typical_product_count": 0,
}

REQUIRED_ALWAYS = [
    "storefront_handle",
    "affiliate_tag",
    "amazon_credential_id",
    "amazon_client_secret",
]


def load():
    """Return the saved config merged over defaults. Missing file returns defaults."""
    if not os.path.exists(CONFIG_PATH):
        return dict(DEFAULTS)
    with open(CONFIG_PATH) as f:
        saved = json.load(f)
    merged = dict(DEFAULTS)
    merged.update(saved)
    return merged


def save(cfg):
    """Write config with owner-only permissions."""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
    os.chmod(CONFIG_PATH, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    return CONFIG_PATH


def update(**changes):
    """Merge changes into the saved config and write it back."""
    cfg = load()
    cfg.update(changes)
    save(cfg)
    return cfg


def missing_fields(cfg=None):
    """Return the list of required settings that are still blank."""
    cfg = cfg or load()
    missing = [k for k in REQUIRED_ALWAYS if not cfg.get(k)]

    if cfg.get("deliver_to_email"):
        for k in ("alert_email", "gmail_address", "gmail_app_password"):
            if not cfg.get(k):
                missing.append(k)

    if cfg.get("deliver_to_slack"):
        for k in ("slack_bot_token", "slack_channel"):
            if not cfg.get(k):
                missing.append(k)

    if not cfg.get("deliver_to_email") and not cfg.get("deliver_to_slack"):
        missing.append("at least one delivery method (email or Slack)")

    return missing


# ── Exclusions ────────────────────────────────────────────────────────────────
# Creators mute products they don't want to hear about again — a sold-out item, a
# brand they've stopped working with, something permanently discounted so it shows
# up every single day.

def exclude_asin(asin, cfg=None):
    cfg = cfg or load()
    asin = asin.strip().upper()
    if asin not in cfg["excluded_asins"]:
        cfg["excluded_asins"].append(asin)
        save(cfg)
    return cfg


def unexclude_asin(asin, cfg=None):
    cfg = cfg or load()
    asin = asin.strip().upper()
    if asin in cfg["excluded_asins"]:
        cfg["excluded_asins"].remove(asin)
        save(cfg)
    return cfg


def exclude_keyword(keyword, cfg=None):
    """Mute anything whose title contains this word — e.g. every phone case."""
    cfg = cfg or load()
    keyword = keyword.strip().lower()
    if keyword and keyword not in cfg["excluded_keywords"]:
        cfg["excluded_keywords"].append(keyword)
        save(cfg)
    return cfg


def unexclude_keyword(keyword, cfg=None):
    cfg = cfg or load()
    keyword = keyword.strip().lower()
    if keyword in cfg["excluded_keywords"]:
        cfg["excluded_keywords"].remove(keyword)
        save(cfg)
    return cfg


def is_excluded(asin, title, cfg):
    """True if this product should be filtered out of the digest."""
    if asin.upper() in [a.upper() for a in cfg.get("excluded_asins", [])]:
        return True
    lowered = (title or "").lower()
    return any(kw in lowered for kw in cfg.get("excluded_keywords", []))


LAST_ITEMS_PATH = os.path.join(CONFIG_DIR, "last_run_items.json")


def save_last_items(items):
    """Keep the day's finds on disk so Claude can hand the creator links and
    captions without them copying anything out of an email."""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    data = [{
        "asin": i.asin, "title": i.title,
        "price": i.current_price, "was": i.original_price,
        "pct_off": i.pct_off, "deal_type": i.deal_type,
        "url": i.affiliate_url,
        "image": i.image_url,
    } for i in items]
    with open(LAST_ITEMS_PATH, "w") as f:
        json.dump(data, f, indent=2)
    return LAST_ITEMS_PATH


def load_last_items():
    if not os.path.exists(LAST_ITEMS_PATH):
        return []
    with open(LAST_ITEMS_PATH) as f:
        return json.load(f)


def record_run(summary):
    """Stamp the time and outcome of a run so staleness can be detected later."""
    from datetime import datetime
    update(last_run_at=datetime.now().isoformat(timespec="seconds"),
           last_run_summary=summary[:300])


def already_ran_today(cfg=None):
    """True if a run already completed today.

    Catch-up schedulers fire a missed job the moment the computer wakes. Without
    this guard, waking the machine twice in a day sends two digests.
    """
    from datetime import datetime
    cfg = cfg or load()
    stamp = cfg.get("last_run_at")
    if not stamp:
        return False
    try:
        return datetime.fromisoformat(stamp).date() == datetime.now().date()
    except ValueError:
        return False


def days_since_last_run(cfg=None):
    """Whole days since the last run, or None if it has never run."""
    from datetime import datetime
    cfg = cfg or load()
    stamp = cfg.get("last_run_at")
    if not stamp:
        return None
    try:
        return (datetime.now() - datetime.fromisoformat(stamp)).days
    except ValueError:
        return None


def schedule_status(cfg=None):
    """Plain-language state of the daily schedule.

    Distinguishes the three cases that look identical from outside: not
    scheduled, scheduled but not yet due today, and scheduled but overdue.
    """
    from datetime import datetime
    cfg = cfg or load()
    hour = cfg.get("scheduled_hour")
    now = datetime.now()

    if hour is None:
        return {"state": "not_scheduled",
                "message": "Sale Scout isn't set to run automatically yet."}

    minute = cfg.get("scheduled_minute", 0) or 0
    due = now.replace(hour=int(hour), minute=int(minute), second=0, microsecond=0)
    ran_today = already_ran_today(cfg)
    at = due.strftime("%-I:%M %p")

    if ran_today:
        return {"state": "ran_today",
                "message": f"Today's run is done. {cfg.get('last_run_summary','')}"}

    if now < due:
        mins = int((due - now).total_seconds() // 60)
        return {"state": "not_due_yet",
                "message": f"Scheduled for {at} — that's about {mins} minutes away. "
                           f"Nothing's wrong; it just hasn't run yet."}

    days = days_since_last_run(cfg)
    return {"state": "overdue",
            "message": f"Scheduled for {at} but today's run hasn't happened"
                       + (f" (last ran {days} day(s) ago)" if days is not None else "")
                       + ". Usually the computer was asleep — it should catch up on "
                         "wake, or it can be run now."}


def redacted(cfg=None):
    """Config safe to print — secrets shown only as length + fixed prefix.

    Never print raw secrets to a terminal Claude can read back; this shows enough
    to spot a truncated paste without exposing the value.
    """
    cfg = cfg or load()
    out = {}
    secret_keys = ("amazon_client_secret", "gmail_app_password", "slack_bot_token")
    for k, v in cfg.items():
        if k in secret_keys and v:
            out[k] = f"<{len(v)} chars, starts '{str(v)[:12]}'>"
        else:
            out[k] = v
    return out
