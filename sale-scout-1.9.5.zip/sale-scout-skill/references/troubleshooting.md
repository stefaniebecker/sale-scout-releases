# When Sale Scout isn't behaving

**Start here every time.** Say to Claude:

> Run the Sale Scout check-up

You don't need to read the rest of this page unless you're curious — Claude will
tell you what's wrong and usually fix it for you. The check-up tests each part — your computer's setup, your Amazon credentials,
your email login, your Slack connection — and tells you which one is broken.
Don't change settings before reading it; guessing from symptoms is how an
afternoon disappears.

---

## "It found 0 products in my storefront"

Your storefront handle is probably wrong.

Open your storefront in a browser. The address looks like:

```
amazon.com/shop/your_handle
                ^^^^^^^^^^^ this part is your handle
```

Tell Claude the full link and it'll extract the right piece.

If the handle is definitely right, Amazon may have changed your page layout. Ask
Claude to run a scan with details shown, and it can see what came back.

---

## "All the price checks failed"

Your Amazon credentials aren't being accepted. Two different causes:

**`invalid_client` or 401** — Amazon doesn't recognise the pair. Usually the
Client Secret got cut off when copied. It should be about **80 characters** and
start `amzn1.oa2-cs.v1.`. If yours is much shorter, copy it again. If you can't
find it, Amazon only ever shows a Secret once — create a new credential pair and
copy both halves.

**400 with a long random-looking code** — a bug in Amazon's own Python library.
Sale Scout already fixes this automatically; the check-up confirms it's active.

---

## "I got an email but the products look wrong"

**Prices look out of date** — Amazon's data can lag its own website by a short
while. Spot-check one link before posting.

**Items I don't want keep appearing** — mute them. Tell Claude "stop showing me
that cooler" and it'll be excluded from now on. You can also mute by keyword to
silence a whole category at once.

**Sale prices that aren't really sales** — some products sit at a permanent
"discount" off an inflated list price. Mute those individually; they'll otherwise
appear every single day.

---

## "I didn't get an email"

Check in this order:

1. **Was anything actually on sale?** If nothing met your threshold, no email is
   sent — that's deliberate, so you don't get empty digests. Ask Claude to run a
   scan and show results without sending.
2. **Spam folder.** Mark it "not spam" once and it should stop.
3. **Did the scheduled run fire?** If your computer was asleep, it didn't. See
   `scheduling.md`.
4. **Gmail login.** The check-up tests this directly.

---

## "I'm getting way too many emails / too many items"

Raise your threshold. Tell Claude "only show me 30% off or more."

Rough guide on a large storefront:

| Threshold | Typical daily items |
|---|---|
| 15% | 40+ — a lot to sift through |
| 25% | 10–20 — the default, and usually the right one |
| 40% | A handful — only genuine standouts |

---

## "The scan takes forever"

Three to five minutes is normal. It reads every product in your storefront, then
checks prices in small batches because Amazon limits how fast anyone can ask.

Much longer than that usually means a very large storefront. It's still working —
let it finish.

---

## "It worked yesterday and doesn't today"

Run the check-up first. Then consider:

- Did you change your Amazon password or regenerate credentials?
- Did your Google App Password get revoked? (Changing your Google password
  revokes them all.)
- Did you rename your storefront?

---

## Still stuck

Ask Claude to run the check-up and read you the results. Everything Sale Scout
does is designed to say *specifically* what went wrong rather than just failing —
if you're getting a vague answer, that itself is worth reporting.
