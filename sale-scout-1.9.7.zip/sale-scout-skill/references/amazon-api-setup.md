# Getting your Amazon access

This is the slow step. It's also the only one you can't hurry.

So do it first. Claude sets up everything else while you wait.

---

## What this is

You already have an **Amazon Associates** account. That's how you earn
commission.

Sale Scout needs one more thing: permission to ask Amazon what things cost.
Amazon calls this the **Creators API**. It's free. You just have to sign up.

Without it, Sale Scout can see what's in your storefront. It just can't see the
prices.

*Seen an old guide mention the Product Advertising API? Same thing, old name.
Amazon renamed it.*

---

## ⚠️ The rule that stops most people

Amazon won't give you this unless you've made **10 sales in the last 30 days**.

That's their rule. We can't change it.

Haven't hit 10 yet? You will. Set Sale Scout up anyway — it'll be ready and
waiting for the day you qualify.

You also need to be in the Amazon Associates program for your country. If you're
in the US, that's the US one.

---

## Step 1 — Find the Creators API page

This is genuinely hard to find, so here's the exact route. These are the real
clicks, not a description.

1. Go to **amazon.com** and make sure you're signed in
2. In the **top left corner**, click **SiteStripe** — the bar that says
   *Influencers and Associates*
3. That takes you to your Associates home page
   (affiliate-program.amazon.com/home)
4. In the **top right corner**, click the **hamburger menu** — the three
   stacked lines ☰
5. Click **Tools**
6. Click **Creators API** in the dropdown

That's the page. Register for access from there.

**Don't see SiteStripe in step 2?** It only appears when you're signed in to
the Amazon account linked to your Associates account. If it's missing, sign out
and back in, or go straight to **affiliate-program.amazon.com/home** and pick up
from step 4.

Amazon's own instructions, if you want them:
affiliate-program.amazon.com/creatorsapi/docs/en-us/onboarding/register-for-creators-api

### Two things that trip people up

**It has to be your main login.** Only the owner of the Amazon Associates
account can sign up. If someone else helps you run your account, this part has
to be done from your login, not theirs.

**Your Associates account has to be fully approved.** Not just applied for.
Amazon has to have looked at it and said yes. Most creators are already there.

If yours is still pending, use the Contact Us form in Associates. Tell them you
need Creators API access and ask them to finish the review.

---

## Step 2 — Generate your two codes

Once you're in, click to make your codes. Amazon gives you two:

| What Amazon calls it | What it looks like |
|---|---|
| **Credential ID** | A long code starting `amzn1.application-oa2-client...` |
| **Client Secret** | A long code starting `amzn1.oa2-cs...` |

**Amazon will ask you to name it.** It's just a label for your own records —
nothing depends on it and you can't get it wrong. **Sale Scout** is a fine
answer.

---

## ⚠️ Copy the second code before you close that page

Amazon shows the **Client Secret** once. Leave the page and it's gone. There's
no way to get it back.

So don't close that tab until Claude has your codes saved.

Already closed it? No problem. Delete that pair in Amazon and make a new one.
Just keep the tab open this time.

---

## Step 3 — Hand them over safely

**Don't paste the Client Secret into the chat.** It's a real credential, and
anything you type in a chat gets saved to that conversation's history. There's
no need for it to go there at all.

You don't have to set any of this up. Claude does it:

1. **Claude opens a blank document on your screen.** You don't make it, name it
   or save it anywhere — it's already done.
2. **You paste both codes into the middle of it and press Command + S.**
3. **You type `done` in the chat.**

That's the whole thing. Claude reads the file, saves your codes properly, and
deletes the file afterwards. It won't print them back at you — you'll only ever
see the last four characters, so you can check it got the right ones.

Paste order doesn't matter. Neither do labels, blank lines, or the instructions
already in the document. Claude picks the codes out on its own, and nothing
needs tidying up.

Your codes end up in a settings file on your own computer that only you can
read. They are never sent anywhere except Amazon. We never see them.

**Already pasted it into the chat?** Nothing bad happens. But if you want to be
tidy, delete that credential in Amazon and generate a fresh pair — it takes two
minutes.

---

## If something doesn't work

**"Invalid client", or something about a 401**
Your second code probably got cut off. It should be long — about 80 characters.
Copy it again.

**A 400 error with a jumble of letters**
That's a bug in Amazon's own software. Sale Scout already works around it. Say
"run the check-up" to Claude and it'll confirm.

**"I already have codes but they don't work"**
Check they're **Creators API** codes. Amazon has other kinds. Anything starting
`AKIA` is a different thing and won't work here. Old Product Advertising API
codes may have stopped working too.

**Amazon says you're not eligible**
It's almost always the 10-sales rule above. It isn't permanent.
