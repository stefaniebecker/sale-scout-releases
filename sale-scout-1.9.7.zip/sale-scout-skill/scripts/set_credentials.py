"""
Sale Scout — saving the Amazon codes without putting them in the chat.

The Client Secret is a real credential and Amazon shows it once. If someone
pastes it into a chat message, it lands in the conversation transcript on their
own machine and goes to the model along with everything else they type. Neither
is a disaster, and neither is necessary.

So the creator drops the codes in a plain text file, Claude runs this script,
and the script does the reading. The codes go straight into the config file and
the handover file is shredded. Nothing sensitive is ever printed — the creator
and Claude both only ever see the last four characters.

    python3 set_credentials.py --from-clipboard id       take it off the clipboard
    python3 set_credentials.py --from-clipboard secret
    python3 set_credentials.py --prepare     make and open a file for them
    python3 set_credentials.py --from-file ~/Downloads/amazon.txt
    python3 set_credentials.py                 type them in yourself, hidden
    python3 set_credentials.py --check         show what's saved, masked

The file can be messy. Two lines, labelled lines, extra blank lines, the whole
page copied out of Amazon — the codes are recognised by how they start, so the
order doesn't matter and neither does the formatting.
"""

import argparse
import os
import subprocess
import sys
from datetime import datetime

import config

# Amazon's own prefixes. These are what make a messy paste safe to read.
ID_PREFIX     = "amzn1.application-oa2-client"
SECRET_PREFIX = "amzn1.oa2-cs"

# Shorter than this and something was truncated on the way over.
MIN_SECRET_LEN = 40

# A real code carries a meaningful tail past the prefix. Requiring one means
# instructions or notes that mention a prefix can never be mistaken for a code.
MIN_TAIL = 12

# Where the handover file goes. Downloads, because every single person can find
# Downloads, and TextEdit's save dialog opens there by default anyway.
DEFAULT_HANDOVER = "~/Downloads/amazon.txt"

# Deliberately avoids writing either prefix out, so the template can never be
# read back as a code.
TEMPLATE = """PASTE YOUR TWO AMAZON CODES BELOW THIS LINE


------------------------------------------------------------




------------------------------------------------------------

That's it. Now press  Command + S  to save, then close this window
and tell Claude you're done.

Don't worry about which code goes first, or about these instructions
being in the file. Claude works it out. Nothing here needs tidying up.
"""


def mask(value):
    """A credential is only ever shown like this."""
    if not value:
        return "(not set)"
    return f"...{value[-4:]} ({len(value)} characters)"


def find_codes(text):
    """Pull the two codes out of whatever the file happens to contain."""
    found = {"id": "", "secret": ""}

    # Split on everything that could separate two codes, so "ID: amzn1...."
    # and a bare line both work.
    for chunk in text.replace(",", " ").replace('"', " ").replace("'", " ").split():
        token = chunk.strip().rstrip(".")
        if token.startswith(ID_PREFIX) and not found["id"]:
            if len(token) >= len(ID_PREFIX) + MIN_TAIL:
                found["id"] = token
        elif token.startswith(SECRET_PREFIX) and not found["secret"]:
            if len(token) >= len(SECRET_PREFIX) + MIN_TAIL:
                found["secret"] = token

    return found["id"], found["secret"]


def prepare(path=None):
    """
    Create the handover file and open it, so nobody has to make one.

    Asking someone to open TextEdit, paste, choose Save As, pick a folder, name
    the file and get the extension right is five chances to get lost. This makes
    all five decisions for them. All that's left is paste and save.
    """
    path = os.path.expanduser(path or DEFAULT_HANDOVER)

    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(TEMPLATE)
        os.chmod(path, 0o600)
    except OSError as e:
        print(f"Couldn't create the file: {e}", file=sys.stderr)
        return 1

    opened = False
    try:
        if sys.platform == "darwin":
            # -e is TextEdit specifically, so this can't land in a code editor
            # or some app that reformats it.
            subprocess.run(["open", "-e", path], check=True,
                           capture_output=True, timeout=15)
            opened = True
        elif sys.platform.startswith("win"):
            subprocess.run(["notepad.exe", path], check=False)
            opened = True
        else:
            subprocess.run(["xdg-open", path], check=True,
                           capture_output=True, timeout=15)
            opened = True
    except Exception:
        opened = False

    if opened:
        print(f"Opened a blank file for them: {path}")
        print()
        print("Tell them, in your own words:")
        print("  - A blank document just opened")
        print("  - Paste BOTH codes into the empty space in the middle")
        print("  - Press Command + S to save (no name or folder to choose)")
        print("  - Say 'done' when saved")
    else:
        print(f"Created the file but couldn't open it: {path}")
        print()
        print("Tell them to open it themselves from their Downloads folder,")
        print("paste both codes in, save, and say 'done'.")

    print()
    print(f"(For Claude: when they say done, run "
          f"python3 set_credentials.py --from-file {path}")
    print(f" ⛔ Do NOT read, cat, grep or open {path} yourself. Reading it puts")
    print(f" the secret into this conversation, which is the one thing this")
    print(f" whole method exists to prevent. Pass the path; let this script read it.)")
    return 0


def read_clipboard():
    """What's on the clipboard right now, or None if we can't tell."""
    try:
        if sys.platform == "darwin":
            out = subprocess.run(["pbpaste"], capture_output=True, timeout=10)
        elif sys.platform.startswith("win"):
            out = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-Clipboard"],
                                 capture_output=True, timeout=15)
        else:
            out = subprocess.run(["xclip", "-selection", "clipboard", "-o"],
                                 capture_output=True, timeout=10)
        return out.stdout.decode("utf-8", "replace").strip()
    except Exception:
        return None


def clear_clipboard():
    """Leave nothing behind on the clipboard."""
    try:
        if sys.platform == "darwin":
            subprocess.run(["pbcopy"], input=b"", timeout=10)
        elif sys.platform.startswith("win"):
            subprocess.run(["powershell", "-NoProfile", "-Command", "Set-Clipboard -Value ' '"],
                           capture_output=True, timeout=15)
        else:
            subprocess.run(["xclip", "-selection", "clipboard"], input=b"", timeout=10)
        return True
    except Exception:
        return False


def from_clipboard(which):
    """
    Take one code straight off the clipboard.

    Simplest possible path: they press Amazon's own copy button, we read the
    clipboard, nothing is ever written to disk and there is no file for anyone
    — including Claude — to read afterwards.
    """
    label  = "Credential ID" if which == "id" else "Client Secret"
    prefix = ID_PREFIX if which == "id" else SECRET_PREFIX

    text = read_clipboard()

    if text is None:
        print("Couldn't read the clipboard on this computer.", file=sys.stderr)
        print("(For Claude: fall back to --prepare and the file method.)",
              file=sys.stderr)
        return 2

    if not text:
        print(f"The clipboard is empty, so there's no {label} to save.",
              file=sys.stderr)
        print(f"Have them click Amazon's copy button next to the {label}, "
              f"then try again.", file=sys.stderr)
        return 1

    token = text.split()[0].strip().rstrip(".") if text.split() else ""

    if not token.startswith(prefix):
        other = "Client Secret" if which == "id" else "Credential ID"
        looks_like_other = token.startswith(
            SECRET_PREFIX if which == "id" else ID_PREFIX)
        print(f"What's on the clipboard isn't the {label}.", file=sys.stderr)
        if looks_like_other:
            print(f"It looks like the {other} — that's the other one. "
                  f"Have them copy the {label} instead.", file=sys.stderr)
        else:
            print(f"The {label} starts with {prefix}... "
                  f"Have them click the copy button next to it and try again.",
                  file=sys.stderr)
        print("Nothing was saved.", file=sys.stderr)
        return 1

    if which == "secret" and len(token) < MIN_SECRET_LEN:
        print(f"That Client Secret is only {len(token)} characters — Amazon's "
              f"are usually around 80, so it got cut off.", file=sys.stderr)
        print("Have them copy the whole thing and try again. Nothing was saved.",
              file=sys.stderr)
        return 1

    if which == "id":
        config.update(amazon_credential_id=token)
    else:
        config.update(amazon_client_secret=token,
                      credentials_saved_at=datetime.now().isoformat(timespec="seconds"),
                      last_rotation_notice_at="")

    cleared = clear_clipboard()

    print(f"Saved the {label}.  {mask(token)}")
    if cleared:
        print("Cleared the clipboard so it isn't left sitting there.")

    cfg = config.load()
    if cfg.get("amazon_credential_id") and cfg.get("amazon_client_secret"):
        print("\nBoth codes are in. Nothing was written to disk along the way, "
              "and nothing passed through the chat.")
    else:
        still = "Client Secret" if which == "id" else "Credential ID"
        print(f"\n(For Claude: now ask them to copy the {still} and say ready, "
              f"then run this again with --from-clipboard "
              f"{'secret' if which == 'id' else 'id'}.)")

    return 0


def shred(path):
    """Overwrite the handover file before deleting it, then confirm it's gone."""
    try:
        size = os.path.getsize(path)
        with open(path, "wb") as f:
            f.write(os.urandom(max(size, 64)))
            f.flush()
            os.fsync(f.fileno())
        os.remove(path)
        return not os.path.exists(path)
    except OSError:
        return False


def from_file(path):
    path = os.path.expanduser(path)

    if not os.path.exists(path):
        print(f"There's no file at {path}.", file=sys.stderr)
        print("Check the name and where it was saved, then try again.",
              file=sys.stderr)
        return 1

    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError as e:
        print(f"Couldn't read that file: {e}", file=sys.stderr)
        return 1

    cred_id, secret = find_codes(text)

    if not cred_id and not secret:
        print("That file doesn't have either code in it.", file=sys.stderr)
        print(f"They start with {ID_PREFIX}... and {SECRET_PREFIX}...",
              file=sys.stderr)
        print("The file was left alone — nothing was saved or deleted.",
              file=sys.stderr)
        return 1

    if not cred_id:
        print("Found the Client Secret, but not the Credential ID.", file=sys.stderr)
        print(f"The Credential ID starts with {ID_PREFIX}...", file=sys.stderr)
        print("The file was left alone so nothing is lost. Add the missing "
              "one and try again.", file=sys.stderr)
        return 1

    if not secret:
        print("Found the Credential ID, but not the Client Secret.", file=sys.stderr)
        print(f"The Client Secret starts with {SECRET_PREFIX}...", file=sys.stderr)
        print("The file was left alone so nothing is lost. Add the missing "
              "one and try again.", file=sys.stderr)
        return 1

    if len(secret) < MIN_SECRET_LEN:
        print(f"The Client Secret looks too short — {len(secret)} characters, "
              f"where Amazon's are usually around 80.", file=sys.stderr)
        print("It was probably cut off when it was copied. Copy the whole "
              "thing and try again.", file=sys.stderr)
        print("The file was left alone so nothing is lost.", file=sys.stderr)
        return 1

    config.update(amazon_credential_id=cred_id, amazon_client_secret=secret,
                  credentials_saved_at=datetime.now().isoformat(timespec="seconds"),
                  last_rotation_notice_at="")

    print("Saved both Amazon codes.")
    print(f"  Credential ID  {mask(cred_id)}")
    print(f"  Client Secret  {mask(secret)}")

    if shred(path):
        print(f"\nThe handover file was overwritten and deleted: {path}")
    else:
        print(f"\nCouldn't delete {path} — please drag it to the Trash "
              "yourself.", file=sys.stderr)

    print("\nThe codes now live in ~/.sale-scout/config.json, readable only by "
          "you. They are never sent anywhere except Amazon.")
    return 0


def interactive():
    """Typed in by hand, hidden as they go. Never echoed, never in the chat."""
    from getpass import getpass

    print("Paste each code and press return. They won't appear as you type.\n")

    try:
        cred_id = getpass("Credential ID:  ").strip()
        secret  = getpass("Client Secret:  ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nStopped. Nothing was saved.", file=sys.stderr)
        return 1

    if not cred_id.startswith(ID_PREFIX):
        print(f"\nThat Credential ID doesn't start with {ID_PREFIX}...",
              file=sys.stderr)
        print("Nothing was saved. Check you copied the right one.", file=sys.stderr)
        return 1

    if not secret.startswith(SECRET_PREFIX):
        print(f"\nThat Client Secret doesn't start with {SECRET_PREFIX}...",
              file=sys.stderr)
        print("Nothing was saved. Check you copied the right one.", file=sys.stderr)
        return 1

    if len(secret) < MIN_SECRET_LEN:
        print(f"\nThat Client Secret is only {len(secret)} characters — Amazon's "
              "are usually around 80, so it was probably cut off.", file=sys.stderr)
        print("Nothing was saved. Copy the whole thing and try again.",
              file=sys.stderr)
        return 1

    config.update(amazon_credential_id=cred_id, amazon_client_secret=secret,
                  credentials_saved_at=datetime.now().isoformat(timespec="seconds"),
                  last_rotation_notice_at="")
    print("\nSaved both Amazon codes.")
    print(f"  Credential ID  {mask(cred_id)}")
    print(f"  Client Secret  {mask(secret)}")
    return 0


def check():
    cfg = config.load()
    print("What's saved right now:")
    print(f"  Credential ID  {mask(cfg.get('amazon_credential_id'))}")
    print(f"  Client Secret  {mask(cfg.get('amazon_client_secret'))}")
    return 0


def main():
    parser = argparse.ArgumentParser(
        description="Save the Amazon codes without them passing through the chat.")
    parser.add_argument("--from-file", metavar="PATH",
                        help="Read the codes from this file, then shred it")
    parser.add_argument("--check", action="store_true",
                        help="Show what's saved, masked")
    parser.add_argument("--prepare", action="store_true",
                        help="Create and open a blank handover file for them")
    parser.add_argument("--from-clipboard", metavar="WHICH", choices=["id", "secret"],
                        help="Take one code off the clipboard: 'id' or 'secret'")
    args = parser.parse_args()

    if args.check:
        return check()
    if args.prepare:
        return prepare()
    if args.from_clipboard:
        return from_clipboard(args.from_clipboard)
    if args.from_file:
        return from_file(args.from_file)
    return interactive()


if __name__ == "__main__":
    sys.exit(main())
