"""
Sale Scout — quiet security housekeeping.

Three small things that protect the creator without ever getting in her way:

  1. A rotation reminder once a year, so a credential that's been sitting on a
     laptop since 2026 doesn't sit there forever.
  2. A permissions check, so the settings file can't quietly become readable by
     anything else on the machine.
  3. A leftover-file check, in case the handover file survived a failed save.

All of it is plain Python on the existing daily schedule. Nothing here calls
Claude, and nothing here is allowed to interrupt a digest — run.py calls these
inside a try/except, and any failure is swallowed.

    python3 security.py          report, and send the notice if one is due
    python3 security.py --check  report only, send nothing
"""

import os
import stat
import sys
from datetime import datetime, date

import config

# A year. Long enough not to nag, short enough to matter.
ROTATE_AFTER_DAYS = 365

# Where set_credentials.py tells people to leave the handover file. If one is
# still sitting there, the save failed partway and a secret is loose on disk.
LIKELY_LEFTOVERS = (
    "~/Downloads/amazon.txt",
    "~/Downloads/amazon-codes.txt",
    "~/Desktop/amazon.txt",
)


def _day(stamp):
    if not stamp:
        return None
    try:
        return datetime.fromisoformat(stamp).date()
    except ValueError:
        return None


# ── 1. Rotation ───────────────────────────────────────────────────────────────

def days_since_credentials_saved(cfg=None):
    """How old the saved Amazon credentials are, or None if we never recorded it."""
    cfg = cfg or config.load()
    saved = _day(cfg.get("credentials_saved_at"))
    if saved is None:
        return None
    return (date.today() - saved).days


def rotation_due(cfg=None):
    """True if it's time to suggest generating a fresh credential pair."""
    cfg = cfg or config.load()

    if not cfg.get("amazon_client_secret"):
        return False

    age = days_since_credentials_saved(cfg)
    if age is None or age < ROTATE_AFTER_DAYS:
        return False

    # Once a year, not once a day for the rest of time.
    told = _day(cfg.get("last_rotation_notice_at"))
    if told and (date.today() - told).days < ROTATE_AFTER_DAYS:
        return False

    return True


def rotation_message(age_days):
    years = max(1, round(age_days / 365))
    when = "a year" if years == 1 else f"{years} years"
    return (
        f"Your Amazon codes have been in use for about {when}.",
        "A yearly tidy-up for your Amazon codes",
        f"Nothing is wrong, and nothing is broken — this is just good "
        f"housekeeping.\n\n"
        f"Your Amazon Creators API codes have been in use for about {when}. "
        f"Security people call swapping them out 'rotating', and doing it once "
        f"a year is a sensible habit for any password-like thing.\n\n"
        f"It takes about two minutes. Open Claude Code and paste this:\n\n"
        f'    "Help me rotate my Amazon codes"\n\n'
        f"Claude walks you through making a fresh pair in Amazon and swapping "
        f"them in. Your daily emails carry on exactly as before.\n\n"
        f"Not urgent. If now's a bad time, it'll mention it again next year.\n\n"
        f"— Stefanie Becker (Merit House) & Kelly Stumpe (The Car Mom)\n"
    )


def send_rotation_notice(cfg=None, verbose=True):
    """Send the yearly nudge, reusing nudge.py's delivery. Returns True if sent."""
    cfg = cfg or config.load()
    if not rotation_due(cfg):
        return False

    age = days_since_credentials_saved(cfg) or ROTATE_AFTER_DAYS
    short, subject, body = rotation_message(age)

    try:
        import nudge
        sent = nudge.desktop_notification(short) | nudge.email(subject, body, cfg)
    except Exception:
        return False

    if sent:
        config.update(last_rotation_notice_at=datetime.now().isoformat(timespec="seconds"))
        if verbose:
            print("Sent the yearly credential-rotation reminder.")

    return sent


# ── 2. File permissions ───────────────────────────────────────────────────────

def check_permissions(fix=True):
    """
    Make sure the settings file is owner-only.

    Returns (ok, message). A backup tool, a copied folder or a careless chmod
    can widen this without anyone noticing.
    """
    path = config.CONFIG_PATH
    if not os.path.exists(path):
        return True, "No settings file yet."

    mode = stat.S_IMODE(os.stat(path).st_mode)
    if mode == 0o600:
        return True, "Settings file is readable only by you."

    if not fix:
        return False, f"Settings file is {oct(mode)}, should be 0o600."

    try:
        os.chmod(path, 0o600)
        return True, (f"Settings file was {oct(mode)} — readable by more than "
                      f"just you. Fixed it back to owner-only.")
    except OSError as e:
        return False, (f"Settings file is {oct(mode)} and couldn't be fixed: {e}")


# ── 3. Leftover handover files ────────────────────────────────────────────────

def leftover_credential_files():
    """Any handover file still sitting on disk with a secret in it."""
    found = []
    for candidate in LIKELY_LEFTOVERS:
        path = os.path.expanduser(candidate)
        if not os.path.exists(path):
            continue
        try:
            blob = open(path, "r", encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        if "amzn1.oa2-cs" in blob or "amzn1.application-oa2-client" in blob:
            found.append(path)
    return found


# ── Called by run.py ──────────────────────────────────────────────────────────

def housekeeping(verbose=False):
    """Everything above, in one call. Never raises."""
    notes = []

    try:
        ok, msg = check_permissions(fix=True)
        if not msg.startswith(("Settings file is readable", "No settings")):
            notes.append(msg)
    except Exception:
        pass

    try:
        for path in leftover_credential_files():
            notes.append(f"There's still a file with your Amazon codes in it at "
                         f"{path}. Worth deleting — the codes are saved already.")
    except Exception:
        pass

    try:
        send_rotation_notice(verbose=verbose)
    except Exception:
        pass

    if verbose:
        for n in notes:
            print(f"  {n}")

    return notes


def main():
    cfg = config.load()
    check_only = "--check" in sys.argv

    print("Sale Scout — security check")
    print("─" * 46)

    ok, msg = check_permissions(fix=not check_only)
    print(f"  Settings file   {msg}")

    age = days_since_credentials_saved(cfg)
    if age is None:
        print("  Credential age  Not recorded "
              "(saved before Sale Scout started tracking this).")
    else:
        due = " — worth rotating" if age >= ROTATE_AFTER_DAYS else ""
        print(f"  Credential age  {age} days{due}")

    leftovers = leftover_credential_files()
    if leftovers:
        for path in leftovers:
            print(f"  Leftover file   {path} still contains your codes — delete it.")
    else:
        print("  Leftover file   None found.")

    if not check_only:
        send_rotation_notice(cfg)


if __name__ == "__main__":
    main()
