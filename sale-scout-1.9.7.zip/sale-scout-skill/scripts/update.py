"""
Sale Scout — self-update.

    python3 update.py --check     see whether a newer version exists
    python3 update.py             download and install it

Settings live in ~/.sale-scout/config.json, outside the skill folder, so an
update never touches credentials, the mute list, or the threshold. The creator's
own logo in assets/ is preserved too.
"""

import hashlib
import io
import json
import os
import shutil
import sys
import tempfile
import urllib.parse
import urllib.request
import zipfile

from version import VERSION, VERSION_URL

SKILL_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# An update installs code that then runs on the creator's machine, so the
# download is only ever fetched over TLS from the host we publish from. A
# link pointing anywhere else is refused rather than followed.
ALLOWED_HOSTS = ("raw.githubusercontent.com", "github.com",
                 "objects.githubusercontent.com")

# A Sale Scout release is ~170KB. The cap stops a bad or hostile link from
# pulling an unbounded amount into memory.
MAX_DOWNLOAD_BYTES = 40 * 1024 * 1024

# Replaced wholesale on update. Anything not listed is left alone, which is how
# a creator's own logo and any local tweaks survive.
REPLACE = ["scripts", "references", "SKILL.md", "README.md"]

# Never overwritten, even inside a replaced folder.
PRESERVE = ["assets/logo.png", "assets/logo.jpg", "assets/logo.jpeg"]


def _parse(v):
    try:
        return tuple(int(p) for p in str(v).strip().split("."))
    except ValueError:
        return (0,)


def safe_url(url):
    """True if this is somewhere we're willing to download runnable code from."""
    try:
        parts = urllib.parse.urlparse(url)
    except ValueError:
        return False
    return parts.scheme == "https" and parts.hostname in ALLOWED_HOSTS


def check():
    """Return (latest_version, url, notes, sha256) or None if already current."""
    if not safe_url(VERSION_URL):
        print("The update address isn't a secure one. Skipping the check.",
              file=sys.stderr)
        return None

    try:
        with urllib.request.urlopen(VERSION_URL, timeout=20) as r:
            info = json.loads(r.read(MAX_DOWNLOAD_BYTES).decode())
    except Exception as e:
        print(f"Couldn't check for updates: {str(e)[:120]}", file=sys.stderr)
        return None

    if not isinstance(info, dict):
        print("The update information was malformed. Skipping.", file=sys.stderr)
        return None

    latest = info.get("version", "")
    if _parse(latest) > _parse(VERSION):
        return (latest, info.get("url", ""), info.get("notes", ""),
                info.get("sha256", ""))
    return None


def install(url, expected_sha=""):
    """Download the release zip and swap in the new files."""
    if not safe_url(url):
        print("That update link doesn't point anywhere Sale Scout trusts, so "
              "nothing was downloaded.", file=sys.stderr)
        print(f"(For Claude: refused {url[:120]} — must be https and one of "
              f"{', '.join(ALLOWED_HOSTS)})", file=sys.stderr)
        return False

    print("Downloading the update...")
    try:
        with urllib.request.urlopen(url, timeout=120) as r:
            data = r.read(MAX_DOWNLOAD_BYTES + 1)
    except Exception as e:
        print(f"Couldn't download the update: {str(e)[:120]}", file=sys.stderr)
        print("Nothing was changed. Worth trying again in a few minutes.",
              file=sys.stderr)
        return False

    if len(data) > MAX_DOWNLOAD_BYTES:
        print("That download was far bigger than a Sale Scout update should be, "
              "so it was refused. Nothing was changed.", file=sys.stderr)
        return False

    # If the published release names a checksum, the bytes have to match it.
    if expected_sha:
        actual = hashlib.sha256(data).hexdigest()
        if actual.lower() != expected_sha.strip().lower():
            print("That download didn't match its published fingerprint, so it "
                  "was thrown away. Nothing was changed.", file=sys.stderr)
            print("This is worth reporting: hello@stefaniebeckerdigital.com",
                  file=sys.stderr)
            return False

    with tempfile.TemporaryDirectory() as tmp:
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                z.extractall(tmp)
        except zipfile.BadZipFile:
            print("That download wasn't a valid update file. Nothing was changed.",
                  file=sys.stderr)
            return False

        # A zip usually contains one top-level folder; step into it if so.
        entries = [e for e in os.listdir(tmp) if not e.startswith(("_", "."))]
        root = tmp
        if len(entries) == 1 and os.path.isdir(os.path.join(tmp, entries[0])):
            root = os.path.join(tmp, entries[0])

        if not os.path.exists(os.path.join(root, "SKILL.md")):
            print("That update doesn't look like Sale Scout. Nothing was changed.",
                  file=sys.stderr)
            return False

        # Keep the creator's own files safe while we swap folders.
        stash = {}
        for rel in PRESERVE:
            src = os.path.join(SKILL_DIR, rel)
            if os.path.exists(src):
                stash[rel] = open(src, "rb").read()

        # Move the old files aside rather than deleting them, so a failure
        # halfway through can be undone. Deleting first and copying second
        # means an interrupted update leaves no working Sale Scout at all.
        backup = tempfile.mkdtemp(prefix="sale-scout-backup-")
        moved = []

        try:
            for item in REPLACE:
                new = os.path.join(root, item)
                old = os.path.join(SKILL_DIR, item)
                if not os.path.exists(new):
                    continue

                if os.path.exists(old):
                    shutil.move(old, os.path.join(backup, item))
                    moved.append(item)

                if os.path.isdir(new):
                    shutil.copytree(new, old)
                else:
                    shutil.copy2(new, old)

            for rel, blob in stash.items():
                dest = os.path.join(SKILL_DIR, rel)
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with open(dest, "wb") as f:
                    f.write(blob)

        except Exception as e:
            print(f"\nThe update failed partway through: {str(e)[:120]}",
                  file=sys.stderr)
            print("Putting your previous version back...", file=sys.stderr)
            for item in moved:
                old = os.path.join(SKILL_DIR, item)
                saved = os.path.join(backup, item)
                if os.path.exists(old):
                    shutil.rmtree(old, ignore_errors=True) if os.path.isdir(old) \
                        else os.remove(old)
                if os.path.exists(saved):
                    shutil.move(saved, old)
            print("Your previous version is back and working. Nothing was lost.",
                  file=sys.stderr)
            shutil.rmtree(backup, ignore_errors=True)
            return False

        shutil.rmtree(backup, ignore_errors=True)

    return True


def main():
    check_only = "--check" in sys.argv
    print(f"Installed version: {VERSION}")

    found = check()
    if not found:
        print("You're on the latest version.")
        return

    latest, url, notes, sha = found
    print(f"Version {latest} is available." + (f"\n  {notes}" if notes else ""))

    if check_only:
        print("\nRun without --check to install it.")
        return

    if not url:
        print("No download link was published for that version.", file=sys.stderr)
        sys.exit(1)

    if install(url, sha):
        print(f"\nUpdated to {latest}. Your settings and logo were kept.")
        print("Run: python3 doctor.py  to confirm everything still works.")
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
