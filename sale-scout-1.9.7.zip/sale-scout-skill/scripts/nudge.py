"""
Sale Scout — the "you never finished" reminder.

Amazon takes days to approve Creators API access. People start setup, hit that
wait, and never come back — not because they gave up, but because nothing ever
reminded them. This is that reminder.

It is called by run.py when the scheduled daily run finds the setup unfinished.
That means it needs no schedule of its own, and — importantly — it never calls
Claude. It is plain Python: a desktop notification, and an email if email is
already working.

    python3 nudge.py           remind if one is due today
    python3 nudge.py --force   remind now, for testing

It stops on its own. Four reminders over three weeks, then silence — a creator
who isn't eligible yet shouldn't be nagged every morning until they are.
"""

import subprocess
import sys
from datetime import datetime, date

import config

# Days after setup began on which a reminder goes out. After the last one we
# stop: by then they know, and a daily poke is just noise.
NUDGE_DAYS = (2, 5, 10, 21)

# config.missing_fields() returns the setting names. Nobody outside this file
# should ever see those words.
FRIENDLY = {
    "amazon_credential_id": "your Amazon Credential ID",
    "amazon_client_secret": "your Amazon Client Secret",
    "storefront_handle":    "your storefront address",
    "affiliate_tag":        "your affiliate tag",
    "alert_email":          "where to send your daily email",
    "gmail_address":        "the address your email sends from",
    "gmail_app_password":   "your email app password",
    "slack_bot_token":      "your Slack connection",
    "slack_channel":        "which Slack channel to post in",
}

WAITING_ON_AMAZON = {"amazon_credential_id", "amazon_client_secret"}


def _parse_day(stamp):
    """Return the date from an ISO stamp, or None."""
    if not stamp:
        return None
    try:
        return datetime.fromisoformat(stamp).date()
    except ValueError:
        return None


def due_today(cfg=None):
    """Is a reminder due today? Returns (yes, days_since_setup_began)."""
    cfg = cfg or config.load()

    began = _parse_day(cfg.get("setup_started_at"))
    if began is None:
        return False, 0

    days = (date.today() - began).days

    # One a day at most, however many times the schedule fires.
    if _parse_day(cfg.get("last_nudge_at")) == date.today():
        return False, days

    return days in NUDGE_DAYS, days


def compose(missing, days):
    """Return (short line for the desktop, subject, body) in plain English."""
    names = [FRIENDLY.get(m, m) for m in missing]
    only_amazon = set(missing) <= WAITING_ON_AMAZON

    if only_amazon:
        short = "Sale Scout is ready — it just needs your Amazon codes."
        subject = "Your Sale Scout is waiting on two codes"
        opening = (
            "Everything else is set up and working. Sale Scout just needs the "
            "two codes from Amazon, and then your daily sale email starts.\n\n"
            "If Amazon has approved you, the codes are on your Creators API "
            "page. If they haven't yet, nothing's wrong — approval takes a few "
            "days and this will be here when it comes through."
        )
    else:
        short = "Sale Scout isn't finished setting up."
        subject = "Sale Scout isn't finished setting up"
        opening = (
            "Sale Scout hasn't sent you anything because setup isn't finished "
            "yet. Here's what's still missing:\n\n"
            + "\n".join(f"  - {n}" for n in names)
        )

    body = (
        f"{opening}\n\n"
        "To finish, open Claude Code and paste this:\n\n"
        '    "Finish setting up Sale Scout"\n\n'
        "Claude picks up exactly where you left off. It takes a couple of "
        "minutes.\n\n"
        f"(It's been {days} days since you started. This is reminder "
        f"{NUDGE_DAYS.index(days) + 1} of {len(NUDGE_DAYS)} — after that "
        "Sale Scout stops reminding you and waits quietly.)\n\n"
        "Stuck? Reply to this or email hello@stefaniebeckerdigital.com.\n\n"
        "— Stefanie Becker (Merit House) & Kelly Stumpe (The Car Mom)\n"
    )

    return short, subject, body


def desktop_notification(short):
    """Show a macOS notification. Silent no-op anywhere else."""
    if sys.platform != "darwin":
        return False
    safe = short.replace('"', "'")
    try:
        subprocess.run(
            ["osascript", "-e",
             f'display notification "{safe}" with title "Sale Scout" '
             f'subtitle "Say \'Finish setting up Sale Scout\' to Claude"'],
            check=True, capture_output=True, timeout=10)
        return True
    except Exception:
        return False


def email(subject, body, cfg):
    """Send the reminder by email. Only possible once email setup is done."""
    address  = cfg.get("gmail_address")
    password = cfg.get("gmail_app_password")
    to       = cfg.get("alert_email") or address
    if not (address and password and to):
        return False

    import smtplib
    from email.mime.text import MIMEText

    try:
        from notify import smtp_host_for, SMTP_PORT
        host, port = smtp_host_for(address, cfg.get("smtp_host", "")), SMTP_PORT
    except Exception:
        host, port = "smtp.gmail.com", 587

    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = address
    msg["To"] = to

    try:
        with smtplib.SMTP(host, port, timeout=30) as smtp:
            smtp.starttls()
            smtp.login(address, password)
            smtp.sendmail(address, to, msg.as_string())
        return True
    except Exception:
        return False


def remind(force=False, verbose=True):
    """Send today's reminder if one is due. Returns True if anything was sent."""
    cfg = config.load()

    missing = config.missing_fields(cfg)
    if not missing:
        return False

    is_due, days = due_today(cfg)
    if not (is_due or force):
        return False

    # --force outside a real nudge day still needs a sane number for the copy.
    if days not in NUDGE_DAYS:
        days = NUDGE_DAYS[0]

    short, subject, body = compose(missing, days)

    notified = desktop_notification(short)
    emailed  = email(subject, body, cfg)

    if notified or emailed:
        config.update(last_nudge_at=datetime.now().isoformat(timespec="seconds"))

    if verbose:
        where = [w for w, ok in (("desktop", notified), ("email", emailed)) if ok]
        print(f"Reminder sent ({', '.join(where)})." if where
              else "Nothing to remind with — no desktop notification and no "
                   "email set up yet.")

    return notified or emailed


if __name__ == "__main__":
    remind(force="--force" in sys.argv)
